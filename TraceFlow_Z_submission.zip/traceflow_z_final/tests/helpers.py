"""Small builders shared by the tests."""
import pandas as pd

from src.contracts import TRANSACTION_COLUMNS


def make_tx(rows):
    """rows: (id, ts, from_acct, from_bank, to_acct, to_bank, amount)."""
    recs = [dict(zip(TRANSACTION_COLUMNS, list(r) + ["UPI", "SCENARIO_01"])) for r in rows]
    return pd.DataFrame(recs, columns=TRANSACTION_COLUMNS)


def make_case(case_id, ids, tokens, risk=80.0, first="2026-10-01T10:00:00", last="2026-10-01T10:20:00",
              amount=1000.0, rank=None):
    c = {"case_id": case_id, "suspicious_account_tokens": list(tokens), "ordered_transaction_ids": list(ids),
         "banks_involved": ["BANK_A"], "total_traced_amount": amount, "risk_score": risk,
         "risk_reasons": ["x"], "first_event_time": first, "last_event_time": last}
    if rank is not None:
        c["priority_rank"] = rank
    return c


# a clean 3-hop chain A001(A) -> B001(B) -> C001(C) -> A002(A), minutes apart
CHAIN = [("T1", "2026-10-01T10:00:00", "A001", "BANK_A", "B001", "BANK_B", 10000.0),
         ("T2", "2026-10-01T10:10:00", "B001", "BANK_B", "C001", "BANK_C", 9500.0),
         ("T3", "2026-10-01T10:20:00", "C001", "BANK_C", "A002", "BANK_A", 9000.0)]
