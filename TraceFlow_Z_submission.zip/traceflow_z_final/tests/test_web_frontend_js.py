"""Runs tests/js_smoke.js (the page's real JavaScript under Node + fake DOM) against the real server."""
import json
import shutil
import subprocess
import threading
import unittest
from pathlib import Path

import dashboard_web
from tests.test_web_dashboard import free_port

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(shutil.which("node"), "node is not installed; front-end script test skipped")
class FrontEndScript(unittest.TestCase):
    def test_page_script_end_to_end_against_real_server(self):
        port = free_port()
        server = dashboard_web.make_server(port)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        try:
            r = subprocess.run(["node", str(ROOT / "tests" / "js_smoke.js"), str(port)],
                               capture_output=True, text=True, timeout=240)
        finally:
            server.shutdown()
            server.server_close()
        self.assertTrue(r.stdout.strip(), r.stderr)
        results = json.loads(r.stdout.strip().splitlines()[-1])
        self.assertNotIn("script_crashed", results, results.get("script_crashed"))
        failed = [k for k, v in results.items() if v is not True]
        self.assertEqual(failed, [], results)
        self.assertGreaterEqual(len(results), 20)


if __name__ == "__main__":
    unittest.main()
