import json
import tempfile
import unittest

from src.contracts import LABEL_COLUMN_NAMES, TRANSACTION_COLUMNS, ContractError, validate_dataset
from src.data_generator import generate_dataset, load_dataset, save_dataset


class DataGeneratorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.accounts, cls.tx, cls.gt = generate_dataset(seed=7)

    def test_reproducible(self):
        a2, t2, g2 = generate_dataset(seed=7)
        self.assertTrue(self.tx.equals(t2) and self.accounts.equals(a2) and self.gt == g2)

    def test_different_seed_differs(self):
        self.assertFalse(self.tx.equals(generate_dataset(seed=8)[1]))

    def test_schema_and_validation(self):
        self.assertEqual(list(self.tx.columns), TRANSACTION_COLUMNS)
        validate_dataset(self.accounts, self.tx)
        self.assertEqual(set(self.accounts["bank_id"]), {"BANK_A", "BANK_B", "BANK_C"})

    def test_labels_are_separate(self):
        self.assertFalse(set(self.tx.columns) & LABEL_COLUMN_NAMES)
        self.assertEqual(self.tx["scenario_id"].nunique(), 1)
        self.assertIn("transaction_ids", self.gt["cases"][0])

    def test_planted_cases_reference_real_transactions(self):
        ids = set(self.tx["transaction_id"])
        kinds = {c["kind"] for c in self.gt["cases"]}
        self.assertEqual(kinds, {"SUSPICIOUS", "LEGIT_LOOKALIKE"})
        for c in self.gt["cases"]:
            self.assertTrue(set(c["transaction_ids"]) <= ids)

    def test_ids_follow_time_not_scenario_creation_order(self):
        ordered = self.tx.sort_values("timestamp", kind="stable")
        self.assertEqual(list(ordered["transaction_id"]), sorted(self.tx["transaction_id"]))
        first_ids = [min(c["transaction_ids"]) for c in self.gt["cases"]]
        self.assertNotEqual(first_ids, sorted(first_ids))   # GT001.. are not in id order

    def test_suspicious_trails_span_banks_without_single_bank_seeing_all(self):
        by_id = self.tx.set_index("transaction_id")
        for c in (c for c in self.gt["cases"] if c["kind"] == "SUSPICIOUS"):
            rows = by_id.loc[c["transaction_ids"]]
            self.assertGreaterEqual((rows["from_bank"] != rows["to_bank"]).sum(), 2)
            for bank in ("BANK_A", "BANK_B", "BANK_C"):
                self.assertFalse(((rows["from_bank"] == bank) | (rows["to_bank"] == bank)).all())

    def test_save_and_load_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            save_dataset(d, self.accounts, self.tx, self.gt)
            a, t, g = load_dataset(d)
            self.assertEqual(len(t), len(self.tx))
            self.assertEqual(g, json.loads(json.dumps(self.gt)))
            self.assertNotIn("kind", t.columns)

    def test_invalid_arguments(self):
        with self.assertRaises(ValueError):
            generate_dataset(accounts_per_bank=3)
        with self.assertRaises(ValueError):
            generate_dataset(accounts_per_bank=10, n_suspicious=20)
        with self.assertRaises(ValueError):
            generate_dataset(n_suspicious=-1)

    def test_validation_rejects_bad_data(self):
        bad = self.tx.copy()
        bad.loc[0, "amount"] = -5
        with self.assertRaises(ContractError):
            validate_dataset(self.accounts, bad)
        bad = self.tx.copy()
        bad.loc[1, "transaction_id"] = bad.loc[0, "transaction_id"]
        with self.assertRaises(ContractError):
            validate_dataset(self.accounts, bad)
        bad = self.tx.copy()
        bad.loc[0, "from_bank"] = "BANK_Z"
        with self.assertRaises(ContractError):
            validate_dataset(self.accounts, bad)


if __name__ == "__main__":
    unittest.main()
