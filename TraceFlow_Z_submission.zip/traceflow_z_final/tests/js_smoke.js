// Executes the REAL web/index.html script under Node with a minimal fake DOM, talking to the REAL
// dashboard_web.py server through a simulated JupyterLab proxy path (/proxy/<port>/).
// This checks the page's logic and rendering output; it does NOT check visual layout in a browser.
const fs = require("fs"), path = require("path");
const port = process.argv[2];
const html = fs.readFileSync(path.join(__dirname, "..", "web", "index.html"), "utf8");
const script = html.match(/<script>([\s\S]*)<\/script>/)[1];

const els = {}, docListeners = {};
function el(id) {
  if (!els[id]) els[id] = {id, innerHTML: "", textContent: "", value: "", disabled: false, style: {}, dataset: {},
    listeners: {}, classList: {toggle() {}, contains() { return false; }, add() {}, remove() {}},
    addEventListener(t, f) { this.listeners[t] = f; }};
  return els[id];
}
const document = {getElementById: el, addEventListener: (t, f) => { docListeners[t] = f; }};
const location = {pathname: `/proxy/${port}/`};
const requested = [];
const fetchStub = (url, opts) => {
  requested.push(url);
  const prefix = `/proxy/${port}/`;
  if (!url.startsWith(prefix)) return Promise.reject(new Error("request escaped the proxy prefix: " + url));
  return fetch(`http://127.0.0.1:${port}/` + url.slice(prefix.length), opts);
};
const api = new Function("document", "location", "fetch",
  script + "\nreturn {state, runAnalysis, setTab};")(document, location, fetchStub);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const click = target => docListeners.click({target});
const plain = (extra = {}) => ({dataset: {}, classList: {contains: () => false}, closest: () => null, ...extra});

(async () => {
  const out = {};
  for (let i = 0; i < 600 && !api.state.result; i++) await sleep(100);
  out.initial_run_completed = !!api.state.result;
  out.requests_use_proxy_prefix = requested.length > 0 && requested.every(u => u.startsWith(`/proxy/${port}/api/`));
  const r0 = api.state.result;
  out.network_panel = /Accounts/.test(els["p-network"].innerHTML) && els["p-network"].innerHTML.includes(String(r0.network.transactions));
  out.tabs = ["Network", "Ranked cases &amp; trails", "Visibility comparison", "Response delay", "Assumptions &amp; limits"]
    .every(t => els["tabs"].innerHTML.includes(t));
  out.cases_panel = ["Why this case was flagged", "<svg", "CASE-", "Risk score"].every(t => els["p-cases"].innerHTML.includes(t));
  out.vis_panel = ["precision", "LOCAL_ONLY", "SELECTED_SIGNALS", "FULL_NETWORK_BENCHMARK", "Pseudonymisation is not privacy"]
    .every(t => els["p-vis"].innerHTML.includes(t)) && els["p-vis"].innerHTML.includes("<rect");
  out.delay_panel = els["p-delay"].innerHTML.includes("<polyline") && els["p-delay"].innerHTML.includes("simulated");
  out.limits_panel = /synthetic/.test(els["p-limits"].innerHTML);
  out.status_line = els["status"].innerHTML.includes("seed 42");

  click(plain({dataset: {tab: "vis"}, classList: {contains: c => c === "tab"}}));
  out.tab_click_switches_tab = api.state.tab === "vis";

  els["sel-mode"].listeners.change({target: {value: "LOCAL_ONLY"}});
  const local = r0.modes.LOCAL_ONLY.cases;
  out.mode_switch_shows_that_modes_cases = api.state.mode === "LOCAL_ONLY" &&
    local.every(c => els["p-cases"].innerHTML.includes(c.case_id)) &&
    els["p-cases"].innerHTML.includes("LOCAL_ONLY");

  if (local.length > 1) {
    const second = local[1].case_id;
    click(plain({closest: () => ({dataset: {case: second}})}));
    out.case_selection_works = api.state.caseId === second && els["p-cases"].innerHTML.includes("Inspect case <span class=\"badge\">" + second);
  } else out.case_selection_works = true;

  click(plain({dataset: {delay: "60"}}));
  out.delay_chip_toggles = !api.state.delays.includes(60);
  click(plain({dataset: {delay: "60"}}));
  out.delay_chip_toggles_back = api.state.delays.includes(60);

  docListeners.input({target: {dataset: {k: "seed"}, value: "7"}});
  out.input_updates_state_and_flags_dirty = api.state.params.seed === 7 && els["dirty"].style.display === "block";
  click(plain({dataset: {inc: "seed", step: "1"}}));
  out.plus_button_steps_value = api.state.params.seed === 8;
  docListeners.input({target: {dataset: {k: "seed"}, value: "7"}});

  const before = JSON.stringify(r0.network.sample);
  await api.runAnalysis();
  out.run_analysis_recomputes_with_new_seed = api.state.result.config.seed === 7 &&
    JSON.stringify(api.state.result.network.sample) !== before && els["dirty"].style.display === "none" &&
    els["status"].innerHTML.includes("seed 7");

  const good = api.state.result;
  docListeners.input({target: {dataset: {k: "n_suspicious"}, value: "99"}});
  await api.runAnalysis();
  out.invalid_parameter_shows_error_and_keeps_old_results = els["error"].innerHTML.includes("n_suspicious") && api.state.result === good;
  docListeners.input({target: {dataset: {k: "n_suspicious"}, value: ""}});
  await api.runAnalysis();
  out.blank_field_shows_error = els["error"].innerHTML.includes("n_suspicious") && api.state.result === good;
  docListeners.input({target: {dataset: {k: "n_suspicious"}, value: "2"}});
  await api.runAnalysis();
  out.recovers_after_fixing_input = els["error"].innerHTML === "" && api.state.result.config.n_suspicious === 2 &&
    api.state.result.modes.FULL_NETWORK_BENCHMARK.metrics.n_planted_cases === 2;

  console.log(JSON.stringify(out));
})().catch(e => { console.log(JSON.stringify({script_crashed: String(e && e.stack || e)})); process.exit(1); });
