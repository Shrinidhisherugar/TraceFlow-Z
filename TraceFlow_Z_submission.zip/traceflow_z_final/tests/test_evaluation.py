import unittest

import pandas as pd

from src.contracts import ContractError
from src.visibility_evaluation import evaluate_cases, tokenize_account
from tests.helpers import make_case

ACCOUNTS = pd.DataFrame({"account_id": [f"A{i}" for i in range(1, 13)],
                         "bank_id": ["BANK_A"] * 12})
TRUTH = {"cases": [
    {"truth_id": "G1", "kind": "SUSPICIOUS", "transaction_ids": ["t1", "t2", "t3"], "accounts": ["A1", "A2", "A3", "A4"]},
    {"truth_id": "G2", "kind": "SUSPICIOUS", "transaction_ids": ["t4", "t5", "t6"], "accounts": ["A5", "A6", "A7", "A8"]},
    {"truth_id": "G3", "kind": "LEGIT_LOOKALIKE", "transaction_ids": ["t7", "t8"], "accounts": ["A9", "A10"]}]}
tok = tokenize_account


class EvaluationTests(unittest.TestCase):
    def test_hand_computed_metrics(self):
        cases = [make_case("c1", ["t1", "t2", "t3"], [tok(f"A{i}") for i in (1, 2, 3, 4)]),
                 make_case("c2", ["t7", "t8"], [tok("A9"), tok("A10")])]
        m = evaluate_cases(cases, TRUTH, ACCOUNTS, latency_ms=12.5)
        self.assertEqual(m["precision"], 0.5)                 # 1 of 2 flagged cases is planted
        self.assertEqual(m["recall"], 0.5)                    # G1 found, G2 missed
        self.assertEqual(m["trail_coverage"], 0.5)            # 3 of 6 planted transactions
        self.assertEqual(m["n_legit_accounts"], 4)            # A9..A12
        self.assertEqual(m["false_positive_rate"], 0.5)       # A9, A10 flagged
        self.assertEqual(m["lookalike_flag_rate"], 1.0)
        self.assertEqual(m["recommendation_latency_ms"], 12.5)

    def test_perfect_detection(self):
        cases = [make_case("c1", ["t1", "t2", "t3"], [tok("A1")]), make_case("c2", ["t4", "t5", "t6"], [tok("A5")])]
        m = evaluate_cases(cases, TRUTH, ACCOUNTS)
        self.assertEqual((m["precision"], m["recall"], m["trail_coverage"]), (1.0, 1.0, 1.0))
        self.assertEqual(m["false_positive_rate"], 0.0)
        self.assertEqual(m["lookalike_flag_rate"], 0.0)

    def test_no_cases_gives_none_precision_not_a_fake_number(self):
        m = evaluate_cases([], TRUTH, ACCOUNTS)
        self.assertIsNone(m["precision"])
        self.assertEqual(m["recall"], 0.0)
        self.assertEqual(m["false_positive_rate"], 0.0)

    def test_no_planted_cases_gives_none_recall(self):
        m = evaluate_cases([], {"cases": []}, ACCOUNTS)
        self.assertIsNone(m["recall"])
        self.assertIsNone(m["trail_coverage"])

    def test_partial_overlap_threshold(self):
        case = make_case("c1", ["t1", "t2", "x1", "x2"], [tok("A1")])        # purity 0.5
        self.assertEqual(evaluate_cases([case], TRUTH, ACCOUNTS)["n_true_positive_cases"], 1)
        self.assertEqual(evaluate_cases([case], TRUTH, ACCOUNTS, overlap_threshold=0.75)["n_true_positive_cases"], 0)

    def test_interface_mismatch_is_caught_at_the_boundary(self):
        wrong_case = {"case_id": "c", "transaction_ids": ["t1"]}          # truth key on a predicted case
        with self.assertRaisesRegex(ContractError, "ordered_transaction_ids"):
            evaluate_cases([wrong_case], TRUTH, ACCOUNTS)
        wrong_truth = {"cases": [{"truth_id": "G", "kind": "SUSPICIOUS", "ordered_transaction_ids": ["t1"], "accounts": []}]}
        with self.assertRaisesRegex(ContractError, "transaction_ids"):
            evaluate_cases([], wrong_truth, ACCOUNTS)

    def test_invalid_arguments(self):
        with self.assertRaises(ValueError):
            evaluate_cases([], TRUTH, ACCOUNTS, overlap_threshold=0)
        with self.assertRaises(ContractError):
            evaluate_cases([], [1, 2], ACCOUNTS)
        with self.assertRaises(ContractError):
            evaluate_cases([], TRUTH, ACCOUNTS.drop(columns=["bank_id"]))


if __name__ == "__main__":
    unittest.main()
