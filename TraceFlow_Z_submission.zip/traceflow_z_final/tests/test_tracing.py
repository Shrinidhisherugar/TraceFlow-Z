import unittest

import networkx as nx

from src.contracts import CASE_REQUIRED_FIELDS, ContractError, validate_case
from src.data_generator import generate_dataset
from src.graph_tracing import (TracingConfig, TracingLimitError, build_transaction_graph,
                               trace_suspicious_paths)
from tests.helpers import CHAIN, make_tx

LOOSE = TracingConfig(min_risk_score=0.0)


class TracingTests(unittest.TestCase):
    def test_graph_structure(self):
        g = build_transaction_graph(make_tx(CHAIN))
        self.assertIsInstance(g, nx.MultiDiGraph)
        self.assertEqual((g.number_of_nodes(), g.number_of_edges()), (4, 3))
        self.assertEqual(g.nodes["B001"]["bank"], "BANK_B")

    def test_multi_hop_case_contract(self):
        cases = trace_suspicious_paths(make_tx(CHAIN), LOOSE)
        self.assertEqual(len(cases), 1)
        c = cases[0]
        validate_case(c)
        for f in CASE_REQUIRED_FIELDS:
            self.assertIn(f, c)
        self.assertEqual(c["ordered_transaction_ids"], ["T1", "T2", "T3"])
        self.assertEqual(c["suspicious_account_tokens"], ["A001", "B001", "C001", "A002"])
        self.assertEqual(c["banks_involved"], ["BANK_A", "BANK_B", "BANK_C"])
        self.assertEqual(c["bank_crossings"], 3)
        self.assertAlmostEqual(c["total_traced_amount"], 28500.0)
        self.assertAlmostEqual(c["origin_amount"], 10000.0)
        self.assertTrue(0 <= c["risk_score"] <= 100)
        self.assertTrue(all(isinstance(r, str) for r in c["risk_reasons"]))

    def test_empty_input(self):
        self.assertEqual(trace_suspicious_paths(make_tx([])), [])

    def test_no_chain_no_case(self):
        rows = [CHAIN[0], ("T9", "2026-10-01T10:05:00", "A005", "BANK_A", "B005", "BANK_B", 8000.0)]
        self.assertEqual(trace_suspicious_paths(make_tx(rows), LOOSE), [])

    def test_cycle_terminates_and_does_not_revisit(self):
        rows = CHAIN + [("T4", "2026-10-01T10:30:00", "A002", "BANK_A", "A001", "BANK_A", 8500.0)]
        cases = trace_suspicious_paths(make_tx(rows), LOOSE)
        for c in cases:
            self.assertEqual(len(c["suspicious_account_tokens"]), len(set(c["suspicious_account_tokens"])))
        self.assertTrue(cases)

    def test_gap_and_retention_limits(self):
        slow = [CHAIN[0], CHAIN[1][:1] + ("2026-10-03T10:10:00",) + CHAIN[1][2:], CHAIN[2]]
        self.assertEqual(trace_suspicious_paths(make_tx(slow), LOOSE), [])
        lossy = [CHAIN[0], CHAIN[1][:6] + (1000.0,), CHAIN[2][:6] + (900.0,)]
        self.assertEqual(trace_suspicious_paths(make_tx(lossy), LOOSE), [])

    def test_order_independent_of_input_row_order(self):
        a = trace_suspicious_paths(make_tx(CHAIN), LOOSE)
        b = trace_suspicious_paths(make_tx(list(reversed(CHAIN))), LOOSE)
        self.assertEqual(a, b)

    def test_invalid_inputs(self):
        with self.assertRaises(ContractError):
            trace_suspicious_paths(make_tx(CHAIN).drop(columns=["amount"]))
        with self.assertRaises(ContractError):
            trace_suspicious_paths(make_tx(CHAIN).assign(is_suspicious=True))
        with self.assertRaises(ContractError):
            trace_suspicious_paths([1, 2, 3])
        with self.assertRaises(ContractError):
            trace_suspicious_paths(make_tx(CHAIN + [CHAIN[0]]))        # duplicate ids
        with self.assertRaises(ContractError):
            trace_suspicious_paths(make_tx(CHAIN).assign(timestamp="not-a-time"))

    def test_config_validation(self):
        with self.assertRaises(ValueError):
            TracingConfig(min_hops=5, max_hops=3)
        with self.assertRaises(ValueError):
            TracingConfig(min_retention=2.0, max_growth=1.0)
        with self.assertRaises(ValueError):
            TracingConfig(min_risk_score=150)

    def test_path_cap_raises(self):
        with self.assertRaises(TracingLimitError):
            trace_suspicious_paths(make_tx(CHAIN), TracingConfig(max_paths=0, min_risk_score=0))

    def test_labels_and_scenario_id_are_not_features(self):
        _, tx, _ = generate_dataset(seed=3)
        shuffled = tx.copy()
        shuffled["scenario_id"] = [f"S{i % 7}" for i in range(len(tx))]
        shuffled["channel"] = "X"
        self.assertEqual(trace_suspicious_paths(tx), trace_suspicious_paths(shuffled))

    def test_planted_trails_recovered_on_generated_data(self):
        _, tx, gt = generate_dataset(seed=42)
        flagged = set().union(*(set(c["ordered_transaction_ids"]) for c in trace_suspicious_paths(tx)))
        for t in (t for t in gt["cases"] if t["kind"] == "SUSPICIOUS"):
            self.assertEqual(set(t["transaction_ids"]) - flagged, set())


if __name__ == "__main__":
    unittest.main()
