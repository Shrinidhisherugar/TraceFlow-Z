"""Dashboard checks that work WITHOUT Streamlit/Plotly installed.

The dashboard script is executed against a hand-written stub of the Streamlit API (and of
Plotly if it is not installed).  This proves the script's own code and its calls into the real
pipeline run without errors and that tables/charts receive real computed values.  It does NOT
prove real Streamlit rendering - that needs the real packages (see README).
"""
import py_compile
import runpy
import sys
import types
import unittest
from pathlib import Path

from src.dashboard_helpers import PipelineConfig, format_value, run_pipeline

ROOT = Path(__file__).resolve().parents[1]


class _Stub:
    def __init__(self, log):
        self._log = log

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        log = self._log

        def call(*a, **k):
            log.append((name, a, k))
            if name in ("number_input", "slider"):
                return a[3]
            if name == "selectbox":
                opts = list(a[1])
                return opts[k.get("index", 0)]
            if name == "multiselect":
                return list(k.get("default", []))
            if name == "button":
                return False
            if name == "columns":
                return [_Stub(log) for _ in range(a[0])]
            if name == "tabs":
                return [_Stub(log) for _ in a[0]]
            if name == "stop":
                raise RuntimeError("dashboard called st.stop(): pipeline error shown to user")
            return None
        return call


class _Fig:
    def __init__(self, *a, **k):
        self.traces = []

    def add_trace(self, t):
        self.traces.append(t)

    def update_layout(self, **k):
        pass


class DashboardSmokeTests(unittest.TestCase):
    def test_every_source_file_compiles(self):
        files = list((ROOT / "src").glob("*.py")) + list((ROOT / "tests").glob("*.py")) + [ROOT / "main.py"]
        self.assertGreater(len(files), 10)
        for f in files:
            py_compile.compile(str(f), doraise=True)

    def test_dashboard_script_runs_against_stubbed_streamlit(self):
        log = []
        st = _Stub(log)
        st.session_state = {}
        st.sidebar = _Stub(log)
        st_mod = types.ModuleType("streamlit")
        st_mod.__dict__.update({k: getattr(st, k) for k in ("session_state", "sidebar")})
        st_mod.__getattr__ = lambda name: getattr(st, name)
        saved = {k: sys.modules.get(k) for k in ("streamlit", "plotly", "plotly.graph_objects")}
        sys.modules["streamlit"] = st_mod
        try:
            try:
                import plotly.graph_objects  # noqa: F401
            except ImportError:
                go = types.ModuleType("plotly.graph_objects")
                go.Figure, go.Scatter, go.Bar = _Fig, dict, dict
                pkg = types.ModuleType("plotly")
                pkg.graph_objects = go
                sys.modules["plotly"], sys.modules["plotly.graph_objects"] = pkg, go
            runpy.run_path(str(ROOT / "src" / "dashboard_app.py"), run_name="dashboard_smoke")
        finally:
            for k, v in saved.items():
                if v is None:
                    sys.modules.pop(k, None)
                else:
                    sys.modules[k] = v
        names = [n for n, _, _ in log]
        self.assertEqual(names.count("tabs"), 1)
        self.assertEqual(names.count("plotly_chart"), 3)   # trail path, visibility bars, delay curves
        self.assertNotIn("error", names)
        markdown = " ".join(str(a[0]) for n, a, _ in log if n == "markdown" and a)
        res = run_pipeline(PipelineConfig())
        precision = res["modes"]["FULL_NETWORK_BENCHMARK"]["metrics"]["precision"]
        self.assertIn(format_value(precision), markdown)        # real computed metric reached the page
        for mode in ("LOCAL_ONLY", "SELECTED_SIGNALS", "FULL_NETWORK_BENCHMARK"):
            self.assertIn(mode, markdown)


if __name__ == "__main__":
    unittest.main()
