import copy
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from src.contracts import validate_case
from src.dashboard_helpers import (PipelineConfig, cases_table, delay_table, html_table, metrics_table,
                                   run_pipeline, trail_edges, trail_layout, write_outputs)
from src.data_generator import generate_dataset
from src.graph_tracing import TracingConfig
from src.visibility_evaluation import MODES

ROOT = Path(__file__).resolve().parents[1]


class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.res = run_pipeline(PipelineConfig(seed=42))

    def test_all_modes_run_and_every_case_meets_the_contract(self):
        self.assertEqual(set(self.res["modes"]), set(MODES))
        for mode, m in self.res["modes"].items():
            for c in m["cases"]:
                validate_case(c)
                self.assertIn("priority_rank", c)
            self.assertEqual(len(m["simulation"]["summary"]), len(self.res["config"].delays_minutes))

    def test_metrics_are_in_range_and_latency_is_measured(self):
        for m in self.res["modes"].values():
            x = m["metrics"]
            for k in ("precision", "recall", "trail_coverage", "false_positive_rate", "lookalike_flag_rate"):
                self.assertTrue(x[k] is None or 0.0 <= x[k] <= 1.0, k)
            self.assertGreater(x["recommendation_latency_ms"], 0)

    def test_full_network_benchmark_recovers_all_planted_trails(self):
        x = self.res["modes"]["FULL_NETWORK_BENCHMARK"]["metrics"]
        self.assertEqual((x["recall"], x["trail_coverage"]), (1.0, 1.0))

    def test_restricted_modes_never_see_more_than_full(self):
        full = self.res["modes"]["FULL_NETWORK_BENCHMARK"]["metrics"]["trail_coverage"]
        for mode in ("LOCAL_ONLY", "SELECTED_SIGNALS"):
            self.assertLessEqual(self.res["modes"][mode]["metrics"]["trail_coverage"], full)

    def test_pipeline_is_deterministic_apart_from_latency(self):
        again = run_pipeline(PipelineConfig(seed=42))
        for mode in MODES:
            self.assertEqual(self.res["modes"][mode]["cases"], again["modes"][mode]["cases"])
            a, b = dict(self.res["modes"][mode]["metrics"]), dict(again["modes"][mode]["metrics"])
            a.pop("recommendation_latency_ms"); b.pop("recommendation_latency_ms")
            self.assertEqual(a, b)

    def test_ground_truth_never_influences_tracing_ranking_or_simulation(self):
        accounts, tx, gt = generate_dataset(seed=42)
        scrambled = copy.deepcopy(gt)
        for c in scrambled["cases"]:
            c["transaction_ids"] = ["TX999999"]       # destroy the labels entirely
        other = run_pipeline(PipelineConfig(seed=42), dataset=(accounts, tx, scrambled))
        for mode in MODES:
            self.assertEqual(self.res["modes"][mode]["cases"], other["modes"][mode]["cases"])
            self.assertEqual(self.res["modes"][mode]["simulation"], other["modes"][mode]["simulation"])
            self.assertNotEqual(self.res["modes"][mode]["metrics"]["recall"],
                                other["modes"][mode]["metrics"]["recall"])   # only metrics react

    def test_display_helpers_use_real_results(self):
        mt = metrics_table(self.res)
        self.assertEqual(list(mt["mode"]), list(MODES))
        full = self.res["modes"]["FULL_NETWORK_BENCHMARK"]
        self.assertEqual(len(cases_table(full["cases"])), len(full["cases"]))
        self.assertEqual(len(delay_table(full["simulation"])), len(self.res["config"].delays_minutes))
        case = full["cases"][0]
        edges = trail_edges(case, self.res["transactions"], self.res["config"].visibility.salt)
        self.assertEqual([e["transaction_id"] for e in edges], case["ordered_transaction_ids"])
        self.assertEqual(set(trail_layout(edges)), set(case["suspicious_account_tokens"]))
        self.assertIn("&lt;", html_table(cases_table(full["cases"]).assign(banks="<script>")))

    def test_config_changes_flow_through(self):
        strict = run_pipeline(PipelineConfig(seed=42, tracing=TracingConfig(min_risk_score=90)))
        self.assertLess(len(strict["modes"]["FULL_NETWORK_BENCHMARK"]["cases"]),
                        len(self.res["modes"]["FULL_NETWORK_BENCHMARK"]["cases"]))

    def test_edge_cases(self):
        none = run_pipeline(PipelineConfig(seed=1, n_suspicious=0, n_lookalikes=0, background_transactions=0))
        for m in none["modes"].values():
            self.assertEqual(m["cases"], [])
            self.assertIsNone(m["metrics"]["precision"])
            self.assertIsNone(m["metrics"]["recall"])
        with self.assertRaises(ValueError):
            run_pipeline(PipelineConfig(accounts_per_bank=2))

    def test_write_outputs(self):
        with tempfile.TemporaryDirectory() as d:
            out = write_outputs(self.res, d)
            names = {p.name for p in out.iterdir()}
            self.assertTrue({"results.json", "metrics.csv", "config.json"} <= names)

    def test_cli_end_to_end(self):
        r = subprocess.run([sys.executable, "main.py", "run"], cwd=ROOT, capture_output=True, text=True, timeout=120)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("Visibility comparison", r.stdout)
        self.assertIn("FULL_NETWORK_BENCHMARK", r.stdout)

    def test_cli_status_and_stop_do_not_touch_foreign_processes(self):
        for cmd in ("status", "stop"):
            r = subprocess.run([sys.executable, "main.py", cmd], cwd=ROOT, capture_output=True, text=True, timeout=30)
            self.assertEqual(r.returncode, 0, r.stderr)


if __name__ == "__main__":
    unittest.main()
