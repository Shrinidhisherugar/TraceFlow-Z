import unittest

import pandas as pd

from src.contracts import ContractError
from src.data_generator import generate_dataset
from src.visibility_evaluation import (MODES, SHARED_SIGNAL_FIELDS, VisibilityConfig, build_views,
                                       run_visibility_mode, tokenize_account)
from tests.helpers import make_tx

TX = make_tx([
    ("T1", "2026-10-01T10:00:00", "A001", "BANK_A", "B001", "BANK_B", 12000.0),   # cross, big
    ("T2", "2026-10-01T10:10:00", "B001", "BANK_B", "B002", "BANK_B", 11900.0),   # intra B
    ("T3", "2026-10-01T10:20:00", "B002", "BANK_B", "C001", "BANK_C", 11800.0),   # cross, big
    ("T4", "2026-10-01T10:30:00", "C001", "BANK_C", "A002", "BANK_A", 900.0),     # cross, small
    ("T5", "2026-10-01T10:40:00", "C002", "BANK_C", "C003", "BANK_C", 5000.0)])   # intra C


def view(views, name):
    return next(v["transactions"] for v in views if v["name"] == name)


class VisibilityTests(unittest.TestCase):
    def test_three_modes_exist(self):
        self.assertEqual(set(MODES), {"LOCAL_ONLY", "SELECTED_SIGNALS", "FULL_NETWORK_BENCHMARK"})

    def test_full_sees_everything(self):
        v = build_views(TX, "FULL_NETWORK_BENCHMARK")
        self.assertEqual(len(v), 1)
        self.assertEqual(set(v[0]["transactions"]["transaction_id"]), set(TX["transaction_id"]))

    def test_local_rule_sender_or_receiver(self):
        v = build_views(TX, "LOCAL_ONLY")
        self.assertEqual(set(view(v, "LOCAL:BANK_A")["transaction_id"]), {"T1", "T4"})
        self.assertEqual(set(view(v, "LOCAL:BANK_B")["transaction_id"]), {"T1", "T2", "T3"})
        self.assertEqual(set(view(v, "LOCAL:BANK_C")["transaction_id"]), {"T3", "T4", "T5"})

    def test_local_rule_sender_only(self):
        v = build_views(TX, "LOCAL_ONLY", VisibilityConfig(local_rule="sender_only"))
        self.assertEqual(set(view(v, "LOCAL:BANK_A")["transaction_id"]), {"T1"})

    def test_selected_signals_pool_only_big_cross_bank(self):
        pooled = view(build_views(TX, "SELECTED_SIGNALS"), "POOLED_SIGNALS")
        self.assertEqual(set(pooled["transaction_id"]), {"T1", "T3"})
        self.assertEqual(set(pooled.columns), set(SHARED_SIGNAL_FIELDS))
        self.assertNotIn("channel", pooled.columns)
        self.assertNotIn("scenario_id", pooled.columns)
        self.assertEqual(list(pooled["amount"]), [12000.0, 12000.0])     # 2 significant figures

    def test_accounts_are_tokenised_consistently(self):
        pooled = view(build_views(TX, "SELECTED_SIGNALS"), "POOLED_SIGNALS")
        full = build_views(TX, "FULL_NETWORK_BENCHMARK")[0]["transactions"]
        self.assertNotIn("A001", set(full["from_account"]))
        self.assertEqual(pooled.iloc[0]["from_account"], tokenize_account("A001"))
        self.assertEqual(tokenize_account("A001"), tokenize_account("A001"))
        self.assertNotEqual(tokenize_account("A001"), tokenize_account("A001", salt="other"))

    def test_unknown_mode_and_bad_config(self):
        with self.assertRaises(ContractError):
            build_views(TX, "EVERYTHING")
        with self.assertRaises(ValueError):
            VisibilityConfig(local_rule="bogus")

    def test_run_mode_output_and_same_input_for_all_modes(self):
        _, tx, _ = generate_dataset(seed=42)
        before = tx.copy()
        for mode in MODES:
            r = run_visibility_mode(tx, mode)
            self.assertEqual(r["mode"], mode)
            self.assertGreaterEqual(r["analysis_ms"], 0)
            self.assertTrue(all("ordered_transaction_ids" in c for c in r["cases"]))
        self.assertTrue(tx.equals(before))      # inputs are never mutated

    def test_local_only_never_exceeds_full_visibility(self):
        _, tx, _ = generate_dataset(seed=42)
        full = set().union(*(set(c["ordered_transaction_ids"]) for c in run_visibility_mode(tx, "FULL_NETWORK_BENCHMARK")["cases"]))
        for mode in ("LOCAL_ONLY", "SELECTED_SIGNALS"):
            cov = set().union(*(set(c["ordered_transaction_ids"]) for c in run_visibility_mode(tx, mode)["cases"]))
            self.assertTrue(cov <= set(tx["transaction_id"]))
            self.assertLessEqual(len(cov & full), len(full))

    def test_label_columns_rejected(self):
        with self.assertRaises(ContractError):
            build_views(TX.assign(label=1), "FULL_NETWORK_BENCHMARK")


if __name__ == "__main__":
    unittest.main()
