import unittest

from src.contracts import ContractError
from src.response_simulator import rank_cases, simulate_response
from tests.helpers import CHAIN, make_case, make_tx

TX = make_tx(CHAIN)
CASE = make_case("C1", ["T1", "T2", "T3"], ["A001"], last="2026-10-01T10:20:00", amount=28500.0)


def sim(cases=None, **kw):
    ranked = rank_cases(cases or [CASE])
    return simulate_response(ranked, TX, **kw)


class RankingTests(unittest.TestCase):
    def test_ranking_orders_and_explains(self):
        hi = make_case("HI", ["T1"], ["a"], risk=90, amount=90000.0)
        lo = make_case("LO", ["T2"], ["b"], risk=40, amount=2000.0)
        ranked = rank_cases([lo, hi])
        self.assertEqual([c["case_id"] for c in ranked], ["HI", "LO"])
        self.assertEqual([c["priority_rank"] for c in ranked], [1, 2])
        self.assertEqual(len(ranked[0]["priority_reasons"]), 3)
        self.assertTrue(0 <= ranked[0]["priority_score"] <= 100)
        self.assertNotIn("priority_rank", lo)                     # inputs not mutated

    def test_empty_and_invalid(self):
        self.assertEqual(rank_cases([]), [])
        with self.assertRaises(ValueError):
            rank_cases([CASE], weights={"risk": 1})
        with self.assertRaises(ContractError):
            rank_cases([{"case_id": "x", "transaction_ids": ["T1"]}])


class SimulationTests(unittest.TestCase):
    def test_hand_computed_funds_remaining(self):
        # terminal transfer T3 = 9000 arrives 10:20; handling 30 min, window 120 min
        r = sim(delays_minutes=[0, 60, 120], handling_minutes=30, cashout_window_minutes=120)
        pct = {s["delay_minutes"]: s["pct_remaining"] for s in r["summary"]}
        self.assertEqual(r["summary"][0]["funds_at_risk"], 9000.0)
        self.assertEqual(pct, {0.0: 75.0, 60.0: 25.0, 120.0: 0.0})

    def test_intervention_before_funds_arrive_keeps_everything(self):
        r = sim(delays_minutes=[0], handling_minutes=0)
        self.assertEqual(r["summary"][0]["pct_remaining"], 100.0)

    def test_monotonic_non_increasing_in_delay(self):
        pcts = [s["pct_remaining"] for s in sim(delays_minutes=[0, 10, 20, 40, 80, 160, 1440])["summary"]]
        self.assertEqual(pcts, sorted(pcts, reverse=True))

    def test_queue_priority_vs_fifo(self):
        rows = [("X1", "2026-10-01T10:00:00", "X1a", "BANK_A", "X1b", "BANK_B", 1000.0),
                ("Y1", "2026-10-01T10:00:00", "Y1a", "BANK_A", "Y1b", "BANK_B", 5000.0)]
        tx = make_tx(rows)
        cx = make_case("CASE-Z", ["X1"], ["a"], first="2026-10-01T10:00:00", last="2026-10-01T10:00:00", rank=2)
        cy = make_case("CASE-A", ["Y1"], ["b"], first="2026-10-01T10:00:00", last="2026-10-01T10:00:00", rank=1)
        kw = dict(delays_minutes=[0], handling_minutes=60, cashout_window_minutes=120)
        prio = simulate_response([cx, cy], tx, queue_policy="priority", **kw)["per_case"]
        waits = {r["case_id"]: r["queue_wait_minutes"] for r in prio}
        self.assertEqual(waits, {"CASE-A": 0.0, "CASE-Z": 60.0})          # rank 1 goes first
        fifo = simulate_response([cx, cy], tx, queue_policy="fifo", **kw)["per_case"]
        self.assertEqual({r["case_id"]: r["queue_wait_minutes"] for r in fifo}, {"CASE-A": 0.0, "CASE-Z": 60.0})
        two = simulate_response([cx, cy], tx, n_investigators=2, queue_policy="priority", **kw)["per_case"]
        self.assertEqual({r["queue_wait_minutes"] for r in two}, {0.0})

    def test_assumptions_are_returned_and_results_are_labelled_simulated(self):
        r = sim()
        self.assertTrue(any("SIMULATED" in a for a in r["assumptions"]))
        self.assertEqual(r["parameters"]["queue_policy"], "priority")

    def test_interface_and_input_errors(self):
        with self.assertRaisesRegex(ContractError, "ordered_transaction_ids"):
            simulate_response([{"case_id": "x", "transaction_ids": ["T1"]}], TX)
        with self.assertRaisesRegex(ContractError, "unknown transaction"):
            simulate_response(rank_cases([make_case("C", ["NOPE"], ["a"])]), TX)
        with self.assertRaisesRegex(ContractError, "priority_rank"):
            simulate_response([CASE], TX)                              # unranked cases + priority policy
        with self.assertRaises(ContractError):
            simulate_response(rank_cases([CASE]), TX.drop(columns=["amount"]))
        for bad in ({"delays_minutes": [-1]}, {"delays_minutes": []}, {"n_investigators": 0},
                    {"cashout_window_minutes": 0}, {"handling_minutes": -5}, {"queue_policy": "random"}):
            with self.assertRaises(ValueError):
                sim(**bad)

    def test_no_cases(self):
        r = simulate_response([], TX, delays_minutes=[0, 30])
        self.assertEqual([s["pct_remaining"] for s in r["summary"]], [None, None])


if __name__ == "__main__":
    unittest.main()
