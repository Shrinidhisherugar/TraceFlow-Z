"""HTTP/API tests for dashboard_web.py. They start the real server on a free local port and run the
REAL pipeline (no stubs).  They prove server behaviour on THIS machine only; see README for what
has not been run on the LinuxONE server."""
import json
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest import mock

import dashboard_web
from src.dashboard_helpers import PipelineConfig, run_pipeline
from src.graph_tracing import TracingConfig

ROOT = Path(__file__).resolve().parents[1]


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class ServerCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.port = free_port()
        cls.server = dashboard_web.make_server(cls.port)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def request(self, path, body=None, method=None, raw=None, headers=None):
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        req = urllib.request.Request(self.base + path, data=data, method=method,
                                     headers=headers or {"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return r.status, r.read(), r.headers
        except urllib.error.HTTPError as e:
            return e.code, e.read(), e.headers

    def run_api(self, **params):
        status, body, _ = self.request("/api/run", params)
        return status, json.loads(body)


class PageAndRoutes(ServerCase):
    def test_index_has_all_required_ui_sections(self):
        status, body, headers = self.request("/")
        html = body.decode()
        self.assertEqual(status, 200)
        self.assertIn("text/html", headers["Content-Type"])
        for text in ["TraceFlow Z - privacy-aware cross-bank fraud investigation", "Scenario", "Tracing",
                     "Response simulation", "Random seed", "Accounts per bank", "Background transactions",
                     "Planted suspicious cases", "Legitimate look-alike cases", "Max wait before forwarding",
                     "Flag threshold", "Signal sharing minimum amount", "Handling time per case", "Investigators",
                     "Cash-out window", "Queue policy", "Delays to compare", "Run analysis",
                     "Network", "Ranked cases & trails", "Visibility comparison", "Response delay",
                     "Assumptions & limits", "Synthetic data only", "not proof of fraud"]:
            self.assertIn(text, html, text)

    def test_page_is_self_contained_and_proxy_safe(self):
        html = self.request("/")[1].decode()
        self.assertFalse(re.findall(r'(?:src|href)\s*=\s*["\']https?://', html), "external asset")
        self.assertNotIn("fetch('/", html)
        self.assertNotIn('fetch("/', html)
        self.assertIn("BASE+\"api/run\"", html)                 # relative, works under /proxy/<port>/

    def test_health_defaults_and_unknown_routes(self):
        self.assertEqual(json.loads(self.request("/api/health")[1]), {"status": "ok"})
        d = json.loads(self.request("/api/defaults")[1])
        self.assertEqual(d["params"]["seed"]["default"], 42)
        self.assertEqual(d["queue_policy"]["choices"], ["priority", "fifo"])
        self.assertEqual(self.request("/nope")[0], 404)
        self.assertEqual(self.request("/api/run")[0], 405)
        self.assertEqual(self.request("/other", {"a": 1})[0], 404)

    def test_server_binds_loopback_only(self):
        self.assertEqual(self.server.server_address[0], "127.0.0.1")


class RunAnalysis(ServerCase):
    def test_run_executes_the_real_pipeline_and_matches_direct_call(self):
        calls = []
        real = run_pipeline

        def spy(cfg, *a, **k):
            calls.append(cfg)
            return real(cfg, *a, **k)
        with mock.patch.object(dashboard_web, "run_pipeline", side_effect=spy):
            status, p = self.run_api(seed=11, n_suspicious=3, min_risk_score=55, queue_policy="fifo",
                                     n_investigators=2, delays_minutes=[0, 60])
        self.assertEqual(status, 200)
        self.assertEqual(len(calls), 1)
        self.assertEqual((calls[0].seed, calls[0].n_suspicious, calls[0].n_investigators, calls[0].queue_policy),
                         (11, 3, 2, "fifo"))
        self.assertEqual(calls[0].tracing.min_risk_score, 55.0)
        direct = real(PipelineConfig(seed=11, n_suspicious=3, tracing=TracingConfig(min_risk_score=55),
                                     queue_policy="fifo", n_investigators=2, delays_minutes=(0, 60)))
        for mode, m in direct["modes"].items():
            got = p["modes"][mode]["metrics"]
            want = {k: v for k, v in m["metrics"].items() if k != "recommendation_latency_ms"}
            for k, v in want.items():
                self.assertEqual(got[k], v, f"{mode}.{k}")
            self.assertEqual([c["case_id"] for c in p["modes"][mode]["cases"]], [c["case_id"] for c in m["cases"]])
            self.assertEqual(p["modes"][mode]["simulation"]["summary"], json.loads(json.dumps(m["simulation"]["summary"])))
            self.assertGreater(got["recommendation_latency_ms"], 0)         # measured
        self.assertEqual(p["network"]["transactions"], len(direct["transactions"]))

    def test_different_seeds_give_different_scenarios(self):
        _, a = self.run_api(seed=1)
        _, b = self.run_api(seed=2)
        self.assertNotEqual(a["network"]["sample"], b["network"]["sample"])
        self.assertNotEqual({c["case_id"] for c in a["modes"]["FULL_NETWORK_BENCHMARK"]["cases"]},
                            {c["case_id"] for c in b["modes"]["FULL_NETWORK_BENCHMARK"]["cases"]})
        _, a2 = self.run_api(seed=1)
        self.assertEqual({c["case_id"] for c in a["modes"]["FULL_NETWORK_BENCHMARK"]["cases"]},
                         {c["case_id"] for c in a2["modes"]["FULL_NETWORK_BENCHMARK"]["cases"]})   # reproducible

    def test_two_meaningfully_different_scenarios(self):
        _, small = self.run_api(accounts_per_bank=20, background_transactions=100, n_suspicious=1, n_lookalikes=0)
        _, big = self.run_api(accounts_per_bank=80, background_transactions=1500, n_suspicious=6, n_lookalikes=4)
        self.assertEqual(small["network"]["accounts"], 60)
        self.assertEqual(big["network"]["accounts"], 240)
        self.assertLess(small["network"]["transactions"], big["network"]["transactions"])
        self.assertEqual(small["modes"]["FULL_NETWORK_BENCHMARK"]["metrics"]["n_planted_cases"], 1)
        self.assertEqual(big["modes"]["FULL_NETWORK_BENCHMARK"]["metrics"]["n_planted_cases"], 6)
        self.assertEqual(small["modes"]["FULL_NETWORK_BENCHMARK"]["metrics"]["n_lookalikes"], 0)
        self.assertEqual(big["modes"]["FULL_NETWORK_BENCHMARK"]["metrics"]["n_lookalikes"], 4)

    def test_threshold_handling_and_delay_controls_change_results(self):
        _, base = self.run_api()
        _, strict = self.run_api(min_risk_score=90)
        full = "FULL_NETWORK_BENCHMARK"
        self.assertLess(len(strict["modes"][full]["cases"]), len(base["modes"][full]["cases"]))
        _, fast = self.run_api(handling_minutes=0, delays_minutes=[0, 30])
        _, slow = self.run_api(handling_minutes=90, delays_minutes=[0, 30])
        self.assertGreater(fast["modes"][full]["simulation"]["summary"][0]["pct_remaining"],
                           slow["modes"][full]["simulation"]["summary"][0]["pct_remaining"])
        self.assertEqual([s["delay_minutes"] for s in fast["modes"][full]["simulation"]["summary"]], [0.0, 30.0])
        _, sig = self.run_api(signal_min_amount=1_000_000)
        pooled = {v["name"]: v["n_records"] for v in sig["modes"]["SELECTED_SIGNALS"]["views"]}
        self.assertEqual(pooled["POOLED_SIGNALS"], 0)                    # nothing meets the sharing threshold

    def test_queue_policy_and_investigators_reach_the_simulation(self):
        _, p = self.run_api(queue_policy="fifo", n_investigators=3)
        sim = p["modes"]["LOCAL_ONLY"]["simulation"]["parameters"]
        self.assertEqual((sim["queue_policy"], sim["n_investigators"]), ("fifo", 3))
        self.assertEqual(p["modes"]["LOCAL_ONLY"]["comparison"]["policy"], "priority")

    def test_each_visibility_mode_returns_its_own_computed_results(self):
        _, p = self.run_api()
        self.assertEqual(p["mode_order"], ["LOCAL_ONLY", "SELECTED_SIGNALS", "FULL_NETWORK_BENCHMARK"])
        views = {m: [v["name"] for v in p["modes"][m]["views"]] for m in p["mode_order"]}
        self.assertEqual(views["FULL_NETWORK_BENCHMARK"], ["FULL_NETWORK"])
        self.assertIn("POOLED_SIGNALS", views["SELECTED_SIGNALS"])
        self.assertNotIn("POOLED_SIGNALS", views["LOCAL_ONLY"])
        flagged = {m: p["modes"][m]["metrics"]["n_flagged_cases"] for m in p["mode_order"]}
        self.assertEqual(flagged, {m: len(p["modes"][m]["cases"]) for m in p["mode_order"]})
        self.assertGreaterEqual(p["modes"]["FULL_NETWORK_BENCHMARK"]["metrics"]["trail_coverage"],
                                p["modes"]["LOCAL_ONLY"]["metrics"]["trail_coverage"])
        case = p["modes"]["FULL_NETWORK_BENCHMARK"]["cases"][0]
        self.assertEqual([e["transaction_id"] for e in case["edges"]], case["ordered_transaction_ids"])
        self.assertTrue(case["risk_reasons"] and case["priority_reasons"])

    def test_ground_truth_never_reaches_the_browser(self):
        status, body, _ = self.request("/api/run", {})
        text = body.decode()
        for forbidden in ("ground_truth", "LEGIT_LOOKALIKE", "truth_id", "\"SUSPICIOUS\"", "\"CHAIN\"", "\"BRANCH\"",
                          "\"pattern\"", "GT00"):
            self.assertNotIn(forbidden, text, forbidden)
        modes_text = json.dumps(json.loads(body)["modes"])
        self.assertNotRegex(modes_text, r"\"(A|B|C)\d{3}\"")   # cases/trails carry tokens, not raw ids
        self.assertNotIn("NaN", text)

    def test_no_cases_scenario_is_handled(self):
        status, p = self.run_api(n_suspicious=0, n_lookalikes=0, background_transactions=0)
        self.assertEqual(status, 200)
        self.assertIsNone(p["modes"]["LOCAL_ONLY"]["metrics"]["precision"])
        self.assertEqual(p["modes"]["FULL_NETWORK_BENCHMARK"]["cases"], [])


class InvalidInput(ServerCase):
    def test_invalid_parameters_return_400_with_a_useful_message_and_server_survives(self):
        bad = [({"seed": -1}, "seed"), ({"seed": "abc"}, "seed"), ({"seed": 1.5}, "seed"), ({"seed": True}, "seed"),
               ({"accounts_per_bank": 5}, "accounts_per_bank"), ({"n_suspicious": 99}, "n_suspicious"),
               ({"min_risk_score": 150}, "min_risk_score"), ({"queue_policy": "random"}, "queue_policy"),
               ({"delays_minutes": []}, "delays_minutes"), ({"delays_minutes": "0"}, "delays_minutes"),
               ({"delays_minutes": [-5]}, "delays_minutes"), ({"n_investigators": 0}, "n_investigators"),
               ({"cashout_window_minutes": 0}, "cashout_window_minutes"), ({"signal_min_amount": None}, "signal_min_amount"),
               ({"handling_minutes": float("inf")}, "handling_minutes")]
        for body, field in bad:
            raw = json.dumps(body).encode()          # json.dumps writes Infinity, which the server must reject
            status, resp, _ = self.request("/api/run", raw=raw)
            self.assertEqual(status, 400, body)
            self.assertIn(field, json.loads(resp)["error"])
        self.assertEqual(json.loads(self.request("/api/health")[1])["status"], "ok")

    def test_impossible_combination_is_reported_not_crashed(self):
        status, p = self.run_api(accounts_per_bank=10, n_suspicious=8, n_lookalikes=8)
        self.assertEqual(status, 400)
        self.assertIn("too many planted scenarios", p["error"])
        self.assertEqual(self.request("/api/health")[0], 200)

    def test_malformed_bodies(self):
        self.assertEqual(self.request("/api/run", raw=b"{not json")[0], 400)
        self.assertEqual(self.request("/api/run", raw=b"[1,2]")[0], 400)
        self.assertEqual(self.request("/api/run", raw=b"")[0], 400)
        self.assertEqual(self.request("/api/run", raw=b"x" * (dashboard_web.MAX_BODY_BYTES + 1))[0], 400)
        self.assertEqual(self.request("/api/health")[0], 200)

    def test_unexpected_internal_error_becomes_500_not_a_crash(self):
        with mock.patch.object(dashboard_web, "run_pipeline", side_effect=RuntimeError("boom")):
            status, body, _ = self.request("/api/run", {})
        self.assertEqual(status, 500)
        self.assertNotIn("boom", body.decode())          # internals are logged, not leaked
        self.assertEqual(self.request("/api/health")[0], 200)


class PortAndLauncher(unittest.TestCase):
    def test_unavailable_port_is_handled_safely(self):
        with socket.socket() as busy:
            busy.bind(("127.0.0.1", 0))
            busy.listen(1)
            port = busy.getsockname()[1]
            with self.assertRaises(dashboard_web.PortInUseError):
                dashboard_web.make_server(port)
            srv = dashboard_web.make_server(port, auto_port=True)
            try:
                self.assertNotEqual(srv.server_address[1], port)
            finally:
                srv.server_close()
            self.assertEqual(dashboard_web.main(["--port", str(port)]), 2)      # exit code, no traceback

    def test_jupyter_port_is_never_used(self):
        with self.assertRaises(dashboard_web.PortInUseError):
            dashboard_web.make_server(38888)

    def test_background_start_status_stop_only_touch_our_process(self):
        port = free_port()
        with tempfile.TemporaryDirectory() as d:
            pid_file = str(Path(d) / "web.pid")
            base = [sys.executable, str(ROOT / "dashboard_web.py"), "--pid-file", pid_file]
            out = subprocess.run(base + ["--port", str(port), "--background"], capture_output=True, text=True, timeout=60)
            self.assertEqual(out.returncode, 0, out.stderr)
            self.assertIn(f"/proxy/{port}/", out.stdout)
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=10) as r:
                    self.assertEqual(json.loads(r.read())["status"], "ok")
                st = subprocess.run(base + ["status"], capture_output=True, text=True, timeout=30)
                self.assertIn("running", st.stdout)
            finally:
                stop = subprocess.run(base + ["stop"], capture_output=True, text=True, timeout=30)
            self.assertIn("stopped", stop.stdout)
            time.sleep(0.3)
            with self.assertRaises(Exception):
                urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=2)
            again = subprocess.run(base + ["stop"], capture_output=True, text=True, timeout=30)
            self.assertIn("Nothing to stop", again.stdout)


if __name__ == "__main__":
    unittest.main()
