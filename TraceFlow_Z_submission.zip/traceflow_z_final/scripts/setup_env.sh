#!/usr/bin/env bash
# Creates .venv INSIDE this project only. Never touches /opt/venv or the Jupyter environment.
# Optional: TFZ_SYSTEM_SITE_PACKAGES=1 reuses already-installed numpy/pandas from the system Python.
set -euo pipefail
cd "$(dirname "$0")/.."
PY="${PYTHON:-python3}"
if [ ! -d .venv ]; then
  "$PY" -m venv .venv ${TFZ_SYSTEM_SITE_PACKAGES:+--system-site-packages}
fi
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo "--- core installed; installing dashboard dependencies (no pyarrow) ---"
python -m pip install -r requirements-dashboard.txt
python -m pip install --no-deps "streamlit>=1.35,<1.50"
python main.py check-env
