# Web dashboard add-on
Files added (nothing existing is overwritten): dashboard_web.py, web/index.html, tests/test_web_dashboard.py,
tests/test_web_frontend_js.py, tests/js_smoke.js.
Start: python3 dashboard_web.py --background --auto-port     Status: python3 dashboard_web.py status
Stop:  python3 dashboard_web.py stop                         Tests:  python3 main.py test
Browser: http://<server-address>:38888/proxy/<port>/  (trailing slash). Accent colour: --accent in web/index.html.
