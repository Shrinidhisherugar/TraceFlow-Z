# Demo script (use the numbers your own run prints)
1. `python main.py run` - show the three-mode table; point out that every value is computed.
2. Dashboard "Network": three banks, transfer counts, sample records; labels are stored separately.
3. "Ranked cases & trails": pick the top case, read the reasons, show transaction ids and bank crossings.
4. "Visibility comparison": same data in all modes. Say what the numbers show - do not assume SELECTED_SIGNALS
   beats LOCAL_ONLY (on seed 42 on my x86_64 run they were identical).
5. Innocent customers: look-alikes flagged and the false-positive rate; the score is an aid, not proof.
6. "Response delay": change delay/handling/investigators and show funds remaining; say these are simulated.
7. "Assumptions & limits": read them aloud. No IBM Z performance claim without measurements on the Z machine.
