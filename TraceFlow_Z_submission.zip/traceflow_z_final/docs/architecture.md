# Architecture and interfaces

Flow: `generate_dataset` -> contract validation -> per-mode views (`build_views`) -> `trace_suspicious_paths`
per view -> `merge_case_lists` -> `rank_cases` -> `evaluate_cases` (+ measured latency) -> `simulate_response`
-> dashboard. All of it is orchestrated by `dashboard_helpers.run_pipeline`; the dashboard only displays
what it returns. `src/contracts.py` imports nothing from `src`, so there are no circular imports.

## Function signatures (frozen)
| Function | Input | Output |
|---|---|---|
| `generate_dataset(seed, accounts_per_bank, background_transactions, n_suspicious, n_lookalikes, start, days)` | ints/str | `(accounts_df, transactions_df, ground_truth dict)` |
| `trace_suspicious_paths(transactions_df, TracingConfig=None)` | df with the 7 tracing columns | `list[case dict]` |
| `build_views(transactions_df, mode, VisibilityConfig=None)` | df, mode string | `list[{"name", "transactions"}]` |
| `run_visibility_mode(transactions_df, mode, TracingConfig, VisibilityConfig)` | | `{"mode","views","cases","analysis_ms"}` |
| `rank_cases(cases, weights=None)` | contract cases | copies + `priority_rank/score/reasons` |
| `evaluate_cases(cases, ground_truth, accounts_df, salt, overlap_threshold, latency_ms)` | | metrics dict |
| `simulate_response(cases, transactions_df, delays_minutes, handling_minutes, n_investigators, cashout_window_minutes, queue_policy)` | ranked cases + the transaction table | `{"assumptions","parameters","per_case","summary"}` |

## The `ordered_transaction_ids` vs `transaction_ids` rule
Predicted cases use `ordered_transaction_ids` everywhere (tracing, ranking, simulation, evaluation, dashboard).
Ground-truth cases use `transaction_ids` and are read only by `evaluate_cases`. `contracts.case_transaction_set`
and `truth_transaction_set` raise a `ContractError` naming the correct key if the wrong one is supplied.
There is no adapter anywhere (tests: `test_interface_mismatch_is_caught_at_the_boundary`).

## Case contract
`case_id, suspicious_account_tokens, ordered_transaction_ids, banks_involved, total_traced_amount (gross sum of
all transfers in the case), risk_score (0-100), risk_reasons, first_event_time, last_event_time`, plus extras
`origin_amount, bank_crossings, trail_depth, n_transactions`; after ranking also `priority_rank, priority_score,
priority_reasons`. Account "tokens" are salted SHA-256 prefixes, applied identically in every mode.

## Visibility modes (same transactions, same evaluation in all three)
* **LOCAL_ONLY** - each bank sees transfers it sends or receives (`sender_only` is available) and traces alone.
* **SELECTED_SIGNALS** - each bank traces its own view and a pooled set of signal records is traced as well.
  Signal = cross-bank transfer with amount >= 5000 (configurable). Shared fields: `transaction_id, timestamp,
  from_account (token), to_account (token), from_bank, to_bank, amount (2 significant figures)`. Not shared:
  `channel`, `scenario_id`, other banks' intra-bank transfers, cross-bank transfers below the minimum. Possible
  leakage: stable tokens link one account across signals; exact timestamps, bank ids and magnitudes stay visible.
  This is not differential privacy, federated learning or a cryptographic guarantee.
* **FULL_NETWORK_BENCHMARK** - every transfer; a benchmark, not a deployment model.
Cases from several views are merged; a case whose transfers are a subset of another case is dropped.

## Tracing and scoring
A trail extends through an account's later outgoing transfer if it is within 720 min, the account is unvisited
(cycle-safe) and forwarded/incoming is in [0.30, 1.10]. Maximal trails of >= 3 transfers that share a
transaction merge into one case. Score = depth (<=20) + cross-bank transfers (<=20) + median forwarding wait
(<=25) + median retention (<=15) + origin amount (<=20); every term appears in `risk_reasons`. Cases scoring
below 50 are not reported. Thresholds were fixed before looking at results and are in `TracingConfig`.

## Metrics (tau = 0.5)
precision = flagged cases with >=50% of their transfers in planted suspicious cases / flagged cases;
recall = planted suspicious cases with >=50% of their transfers covered by flagged transfers / planted cases;
trail coverage = planted-suspicious transfers recovered / all planted-suspicious transfers;
false-positive rate = legitimate accounts (not in any planted suspicious case) appearing in a flagged case /
all legitimate accounts; look-alike flag rate = legitimate look-alike cases covered >= tau / look-alikes;
latency = measured wall-clock ms for views + tracing + ranking. Zero denominators give `None` (shown as n/a).

## Response simulation assumptions
See `simulate_response` docstring / the returned `assumptions` (A1-A5): alert at last traced transfer,
delay + investigator queue + handling time, funds at risk = terminal transfers, linear drain over the cash-out
window, results are simulated potential funds and never actual recoveries.
