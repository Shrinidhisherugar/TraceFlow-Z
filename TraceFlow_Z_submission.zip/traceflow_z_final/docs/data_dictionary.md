# Data dictionary
## transactions.csv
| Field | Type | Meaning |
|---|---|---|
| transaction_id | str | Unique id `TX000001...`, assigned after a global time sort (does not encode scenario) |
| timestamp | str | ISO 8601 `YYYY-MM-DDTHH:MM:SS` |
| from_account / to_account | str | Account ids such as `A001` (prefix = bank) |
| from_bank / to_bank | str | `BANK_A`, `BANK_B`, `BANK_C` |
| amount | float | Positive amount |
| channel | str | UPI, NEFT, IMPS, BANK_TRANSFER (never used as a feature) |
| scenario_id | str | `SCENARIO_01` for the whole run (never used as a feature) |
## accounts.csv
`account_id`, `bank_id`.
## ground_truth.json (evaluation only; never passed to tracing, ranking or simulation)
`cases[]`: `truth_id, kind (SUSPICIOUS | LEGIT_LOOKALIKE), pattern, transaction_ids, accounts, banks`.
Suspicious patterns: CHAIN (4-5 fast hops, 93-99% forwarded), BRANCH (chain with a side leg).
Look-alikes (legitimate): ESCROW, MERCHANT, FAMILY - same multi-bank shape, different tempo/size.
