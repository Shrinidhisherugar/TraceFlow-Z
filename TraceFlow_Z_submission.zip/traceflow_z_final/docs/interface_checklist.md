# Interface / requirements checklist (status = what was actually run)
| Requirement | Where | Evidence | Status |
|---|---|---|---|
| Common transaction schema, exact field names | `contracts.py` | `test_data`, `test_tracing` | Tested (x86_64) |
| Labels separate from inputs; leak guard | `contracts.reject_label_columns`, `data_generator` | `test_labels_are_separate`, `test_ground_truth_never_influences...` | Tested |
| `ordered_transaction_ids` vs `transaction_ids` | `contracts.py` | `test_interface_mismatch_is_caught_at_the_boundary`, `test_interface_and_input_errors` | Tested |
| Reproducible generation | `data_generator.py` | `test_reproducible` | Tested |
| Multi-bank trails traced, cycles safe | `graph_tracing.py` | `test_multi_hop_case_contract`, `test_cycle_terminates...` | Tested |
| Three visibility modes, documented shared fields | `visibility_evaluation.py` | `test_visibility` | Tested |
| Metrics vs separate ground truth, hand-checked | `evaluate_cases` | `test_hand_computed_metrics` | Tested |
| Explainable ranking | `rank_cases` | `test_ranking_orders_and_explains` | Tested |
| Delay simulation with assumptions, hand-checked | `simulate_response` | `test_hand_computed_funds_remaining`, queue tests | Tested |
| Full pipeline + CLI | `dashboard_helpers.py`, `main.py` | `test_integration` | Tested |
| Dashboard calls real pipeline | `dashboard_app.py` | stub-based `test_dashboard_smoke` | Tested only against a STUB |
| Real Streamlit start, HTTP check, Jupyter proxy | - | - | **NOT verified (needs your environment)** |
| s390x installation | `requirements*.txt` | - | **NOT verified** |
| Latency is measured, not invented | `run_pipeline` | `test_metrics_are_in_range_and_latency_is_measured` | Tested |
