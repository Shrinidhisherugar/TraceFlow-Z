#!/usr/bin/env python3
"""TraceFlow Z - standard-library web dashboard (no Streamlit, Flask, Plotly or pyarrow).

Run from the project root:
    python dashboard_web.py                      # foreground on 127.0.0.1:8512
    python dashboard_web.py --background         # detached; log in logs/dashboard_web.log
    python dashboard_web.py status | stop        # only the process started by this launcher
    python dashboard_web.py --port 8513 --auto-port

Routes (all relative, so it works under a JupyterLab proxy at /proxy/<port>/):
    GET  /                the single-page dashboard (web/index.html)
    GET  /api/health      {"status": "ok"}
    GET  /api/defaults    default parameters and their allowed ranges
    POST /api/run         JSON parameters -> runs the REAL pipeline -> JSON results

Every number returned by /api/run comes from ``src.dashboard_helpers.run_pipeline``.  Ground truth
is used only inside that pipeline's evaluation step and is never serialised to the browser.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.contracts import ContractError  # noqa: E402
from src.dashboard_helpers import PipelineConfig, run_pipeline, trail_edges  # noqa: E402
from src.graph_tracing import TracingConfig, TracingLimitError  # noqa: E402
from src.visibility_evaluation import (MODE_DESCRIPTIONS, MODES, NOT_SHARED_FIELDS,  # noqa: E402
                                       SHARED_SIGNAL_FIELDS, VisibilityConfig)

INDEX_FILE = ROOT / "web" / "index.html"
DEFAULT_PORT = 8512
HOST = "127.0.0.1"                      # loopback only; reach it through the Jupyter proxy
MAX_BODY_BYTES = 64 * 1024
DELAY_CHOICES = [0, 15, 30, 60, 120, 240, 480, 1440]

# name: (kind, minimum, maximum, default)   kind: int | float
PARAM_SPECS = {
    "seed": ("int", 0, 10_000_000, 42),
    "accounts_per_bank": ("int", 10, 300, 40),
    "background_transactions": ("int", 0, 5000, 600),
    "n_suspicious": ("int", 0, 8, 4),
    "n_lookalikes": ("int", 0, 8, 3),
    "max_gap_minutes": ("float", 1, 1440, 720),
    "min_risk_score": ("float", 0, 100, 50),
    "signal_min_amount": ("float", 0, 1_000_000, 5000),
    "handling_minutes": ("float", 0, 1440, 30),
    "n_investigators": ("int", 1, 20, 1),
    "cashout_window_minutes": ("float", 1, 10080, 120),
}
POLICIES = ("priority", "fifo")
_RUN_LOCK = threading.Lock()            # one pipeline run at a time (CPU-bound, bounds memory)


class ParamError(ValueError):
    """Invalid request parameters (reported to the browser as HTTP 400)."""


def _number(name, value, kind, lo, hi):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ParamError(f"{name} must be a number")
    if isinstance(value, float) and not math.isfinite(value):
        raise ParamError(f"{name} must be finite")
    if kind == "int":
        if int(value) != value:
            raise ParamError(f"{name} must be a whole number")
        value = int(value)
    else:
        value = float(value)
    if not lo <= value <= hi:
        raise ParamError(f"{name} must be between {lo} and {hi} (got {value})")
    return value


def parse_params(data):
    """Validate a request body and return a PipelineConfig. Missing fields use the defaults."""
    if not isinstance(data, dict):
        raise ParamError("request body must be a JSON object")
    vals = {}
    for name, (kind, lo, hi, default) in PARAM_SPECS.items():
        vals[name] = _number(name, data.get(name, default), kind, lo, hi)
    policy = data.get("queue_policy", "priority")
    if policy not in POLICIES:
        raise ParamError(f"queue_policy must be one of {list(POLICIES)}")
    delays = data.get("delays_minutes", DELAY_CHOICES)
    if not isinstance(delays, list) or not 1 <= len(delays) <= 12:
        raise ParamError("delays_minutes must be a list of 1-12 numbers")
    delays = tuple(sorted({_number("delays_minutes", d, "float", 0, 10080) for d in delays}))
    try:
        return PipelineConfig(
            seed=vals["seed"], accounts_per_bank=vals["accounts_per_bank"],
            background_transactions=vals["background_transactions"],
            n_suspicious=vals["n_suspicious"], n_lookalikes=vals["n_lookalikes"],
            tracing=TracingConfig(max_gap_minutes=vals["max_gap_minutes"],
                                  min_risk_score=vals["min_risk_score"]),
            visibility=VisibilityConfig(signal_min_amount=vals["signal_min_amount"]),
            delays_minutes=delays, handling_minutes=vals["handling_minutes"],
            n_investigators=vals["n_investigators"],
            cashout_window_minutes=vals["cashout_window_minutes"], queue_policy=policy)
    except ValueError as exc:
        raise ParamError(str(exc)) from exc


def _clean(obj):
    """Make a structure strictly JSON-safe (numpy scalars -> python, NaN/inf -> None)."""
    if isinstance(obj, dict):
        return {str(k): _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    if hasattr(obj, "item") and not isinstance(obj, (str, bytes)):
        obj = obj.item()
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    return obj


CASE_FIELDS = ("case_id", "priority_rank", "priority_score", "risk_score", "risk_reasons",
               "priority_reasons", "banks_involved", "n_transactions", "trail_depth",
               "total_traced_amount", "origin_amount", "bank_crossings", "first_event_time",
               "last_event_time", "ordered_transaction_ids", "suspicious_account_tokens")


def build_payload(results):
    """Convert pipeline results to the browser JSON. Ground truth is deliberately excluded."""
    cfg, tx, acc = results["config"], results["transactions"], results["accounts"]
    pairs = tx.groupby(["from_bank", "to_bank"]).size().reset_index(name="transfers")
    modes = {}
    for mode, m in results["modes"].items():
        cases = []
        for c in m["cases"]:
            item = {k: c.get(k) for k in CASE_FIELDS}
            item["edges"] = trail_edges(c, tx, cfg.visibility.salt)
            cases.append(item)
        sim = m["simulation"]
        modes[mode] = {
            "description": MODE_DESCRIPTIONS[mode], "views": m["views"], "metrics": m["metrics"],
            "cases": cases,
            "simulation": {"summary": sim["summary"], "parameters": sim["parameters"],
                           "assumptions": sim["assumptions"]},
            "comparison": {"policy": m["comparison_policy"],
                           "summary": m["comparison_simulation"]["summary"]}}
    payload = {
        "config": {"seed": cfg.seed, "accounts_per_bank": cfg.accounts_per_bank,
                   "background_transactions": cfg.background_transactions,
                   "n_suspicious": cfg.n_suspicious, "n_lookalikes": cfg.n_lookalikes,
                   "max_gap_minutes": cfg.tracing.max_gap_minutes,
                   "min_risk_score": cfg.tracing.min_risk_score,
                   "signal_min_amount": cfg.visibility.signal_min_amount,
                   "handling_minutes": cfg.handling_minutes, "n_investigators": cfg.n_investigators,
                   "cashout_window_minutes": cfg.cashout_window_minutes,
                   "queue_policy": cfg.queue_policy, "delays_minutes": list(cfg.delays_minutes)},
        "network": {"accounts": int(len(acc)), "transactions": int(len(tx)),
                    "cross_bank": int((tx["from_bank"] != tx["to_bank"]).sum()),
                    "bank_pairs": pairs.to_dict("records"),
                    "sample": tx.head(25).to_dict("records")},
        "modes": modes, "mode_order": list(MODES),
        "shared_fields": [{"field": k, "shared_as": v[0], "leakage": v[1]}
                          for k, v in SHARED_SIGNAL_FIELDS.items()],
        "not_shared": list(NOT_SHARED_FIELDS)}
    return _clean(payload)


def execute_run(data):
    """Validate -> run the real pipeline -> payload. Raises ParamError for bad input."""
    cfg = parse_params(data)
    t0 = time.perf_counter()
    with _RUN_LOCK:
        try:
            results = run_pipeline(cfg)
        except (ValueError, ContractError, TracingLimitError) as exc:
            raise ParamError(f"{type(exc).__name__}: {exc}") from exc
    payload = build_payload(results)
    payload["server_ms"] = round((time.perf_counter() - t0) * 1000.0, 1)
    return payload


class Handler(BaseHTTPRequestHandler):
    server_version = "TraceFlowZ/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.log_date_time_string(), fmt % args))

    def _send(self, status, body, ctype="application/json; charset=utf-8"):
        raw = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                         "script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:")
        self.end_headers()
        self.wfile.write(raw)

    def _json(self, status, obj):
        self._send(status, json.dumps(_clean(obj), allow_nan=False))

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html"):
            try:
                self._send(200, INDEX_FILE.read_bytes(), "text/html; charset=utf-8")
            except OSError:
                self._json(500, {"error": "web/index.html is missing"})
        elif path == "/api/health":
            self._json(200, {"status": "ok"})
        elif path == "/api/defaults":
            self._json(200, {
                "params": {k: {"kind": s[0], "min": s[1], "max": s[2], "default": s[3]}
                           for k, s in PARAM_SPECS.items()},
                "queue_policy": {"choices": list(POLICIES), "default": "priority"},
                "delay_choices": DELAY_CHOICES, "default_delays": DELAY_CHOICES})
        elif path == "/api/run":
            self._json(405, {"error": "use POST with a JSON body"})
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        if path != "/api/run":
            return self._json(404, {"error": "not found"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return self._json(400, {"error": "invalid Content-Length"})
        if length <= 0 or length > MAX_BODY_BYTES:
            return self._json(400, {"error": f"body must be 1-{MAX_BODY_BYTES} bytes"})
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return self._json(400, {"error": "body is not valid JSON"})
        try:
            self._json(200, execute_run(data))
        except ParamError as exc:
            self._json(400, {"error": str(exc)})
        except Exception:                    # never let one request kill the server
            traceback.print_exc()
            self._json(500, {"error": "internal error while running the analysis; see the server log"})


class PortInUseError(OSError):
    pass


def port_is_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind((HOST, port))
            return True
        except OSError:
            return False


def make_server(port, auto_port=False):
    """Bind a server on 127.0.0.1. Raises PortInUseError instead of crashing or killing anything."""
    candidates = [port] + (list(range(port + 1, port + 40)) if auto_port else [])
    for p in candidates:
        if p == 38888 or not port_is_free(p):        # never use the JupyterLab port
            continue
        try:
            return ThreadingHTTPServer((HOST, p), Handler)
        except OSError:
            continue
    raise PortInUseError(f"port {port} is not available" +
                         ("" if auto_port else " (use --auto-port to pick another)"))


# ------------------------------------------------------------------ launcher helpers
def _state_file(args):
    return Path(args.pid_file) if args.pid_file else ROOT / "run" / "dashboard_web.pid"


def _read_state(path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def _is_ours(pid):
    try:
        cmd = Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ").decode()
    except OSError:
        return False
    return "dashboard_web.py" in cmd


def cmd_status(args):
    st = _read_state(_state_file(args))
    if not st or not _is_ours(st["pid"]):
        print("TraceFlow Z web dashboard: not running (no matching process from this launcher)")
        return 0
    try:
        body = urllib.request.urlopen(f"http://{HOST}:{st['port']}/api/health", timeout=5).read().decode()
        print(f"running: pid {st['pid']}, port {st['port']}, health -> {body.strip()}")
        print(f"JupyterLab URL: http://<server-address>:38888/proxy/{st['port']}/")
        return 0
    except Exception as exc:
        print(f"process {st['pid']} exists but the health check failed: {exc}")
        return 1


def cmd_stop(args):
    path = _state_file(args)
    st = _read_state(path)
    if not st or not _is_ours(st["pid"]):
        print("Nothing to stop: no web dashboard process from this launcher was found "
              "(JupyterLab and other processes are never touched).")
        return 0
    os.kill(st["pid"], 15)
    for _ in range(50):
        if not _is_ours(st["pid"]):
            break
        time.sleep(0.1)
    path.unlink(missing_ok=True)
    print(f"stopped dashboard pid {st['pid']}")
    return 0


def cmd_start(args):
    try:
        server = make_server(args.port, args.auto_port)
    except PortInUseError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    port = server.server_address[1]
    state = _state_file(args)
    if args.background and not args.foreground_child:
        server.server_close()                      # release the probe; the child binds it again
        log_dir = ROOT / "logs"
        log_dir.mkdir(exist_ok=True)
        log = open(log_dir / "dashboard_web.log", "ab")
        cmd = [sys.executable, str(Path(__file__).resolve()), "--port", str(port), "--foreground-child",
               "--pid-file", str(state)]
        proc = subprocess.Popen(cmd, stdout=log, stderr=log, cwd=ROOT, start_new_session=True)
        state.parent.mkdir(parents=True, exist_ok=True)
        state.write_text(json.dumps({"pid": proc.pid, "port": port}))
        for _ in range(50):                        # wait up to 5 s for the child to answer
            time.sleep(0.1)
            try:
                urllib.request.urlopen(f"http://{HOST}:{port}/api/health", timeout=1).read()
                break
            except Exception:
                continue
        print(f"started in background: pid {proc.pid}, port {port}; log: logs/dashboard_web.log")
        print(f"local URL:      http://{HOST}:{port}/")
        print(f"JupyterLab URL: http://<server-address>:38888/proxy/{port}/   (keep the trailing slash)")
        return 0
    if args.foreground_child:
        state.parent.mkdir(parents=True, exist_ok=True)
        state.write_text(json.dumps({"pid": os.getpid(), "port": port}))
    print(f"TraceFlow Z listening on http://{HOST}:{port}/  (Ctrl+C to stop)", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", nargs="?", choices=["start", "status", "stop"], default="start")
    p.add_argument("--port", type=int, default=DEFAULT_PORT)
    p.add_argument("--auto-port", action="store_true", help="if the port is busy, pick the next free one")
    p.add_argument("--background", action="store_true")
    p.add_argument("--foreground-child", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--pid-file", default=None, help="override the PID/state file (default run/dashboard_web.pid)")
    args = p.parse_args(argv)
    return {"start": cmd_start, "status": cmd_status, "stop": cmd_stop}[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
