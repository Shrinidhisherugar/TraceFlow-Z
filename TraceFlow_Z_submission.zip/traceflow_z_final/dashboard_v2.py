from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import csv, json, html

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
MODES = ["LOCAL_ONLY", "SELECTED_SIGNALS", "FULL_NETWORK_BENCHMARK"]
LABELS = {
    "LOCAL_ONLY": "Local only",
    "SELECTED_SIGNALS": "Selected signals",
    "FULL_NETWORK_BENCHMARK": "Full network benchmark"
}

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}

def read_csv(path):
    try:
        with path.open(newline="", encoding="utf-8-sig") as f:
            return list(csv.DictReader(f))
    except Exception:
        return []

def esc(x):
    return html.escape(str(x if x is not None else ""))

def pct(v):
    try:
        return f"{float(v)*100:.1f}%"
    except Exception:
        return "—"

def number(v, digits=2):
    try:
        return f"{float(v):,.{digits}f}"
    except Exception:
        return "—"

def table(rows, columns):
    if not rows:
        return "<p class='muted'>No saved records available.</p>"
    h = "<div class='tablewrap'><table><thead><tr>"
    h += "".join(f"<th>{esc(label)}</th>" for _, label in columns)
    h += "</tr></thead><tbody>"
    for r in rows:
        h += "<tr>" + "".join(f"<td>{esc(r.get(key, '—'))}</td>" for key, _ in columns) + "</tr>"
    return h + "</tbody></table></div>"

def page(query):
    results = read_json(OUT / "results.json")
    metrics = {r.get("mode"): r for r in read_csv(OUT / "metrics.csv")}
    mode = query.get("mode", ["FULL_NETWORK_BENCHMARK"])[0]
    if mode not in MODES:
        mode = MODES[-1]

    case_rows = read_csv(OUT / f"cases_{mode}.csv")
    delay_rows = read_csv(OUT / f"delay_{mode}.csv")
    selected = metrics.get(mode, {})
    mode_results = results.get(mode, {})
    views = mode_results.get("views", [])
    assumptions = mode_results.get("assumptions", [])

    overview = []
    for m in MODES:
        r = metrics.get(m, {})
        overview.append({
            "mode": LABELS[m],
            "flagged_cases": r.get("flagged_cases", "—"),
            "precision": pct(r.get("precision")),
            "recall": pct(r.get("recall")),
            "trail_coverage": pct(r.get("trail_coverage")),
            "false_positive_rate": pct(r.get("false_positive_rate")),
            "latency_ms": number(r.get("latency_ms"))
        })

    max_cases = max([int(r.get("flagged_cases", 0) or 0) for r in metrics.values()] or [1])
    bars = ""
    for m in MODES:
        r = metrics.get(m, {})
        try:
            width = float(r.get("trail_coverage", 0))*100
        except Exception:
            width = 0
        bars += f"""<div class='barrow'><span>{esc(LABELS[m])}</span>
        <div class='bar'><i style='width:{max(0,min(100,width)):.1f}%'></i></div>
        <b>{width:.1f}%</b></div>"""

    options = "".join(
        f"<option value='{m}' {'selected' if m == mode else ''}>{LABELS[m]}</option>"
        for m in MODES
    )
    case_table = table(case_rows, [
        ("rank","Rank"),("case_id","Case ID"),("priority","Priority"),
        ("risk_score","Risk score"),("banks","Banks"),("transfers","Transfers"),
        ("depth","Trail depth"),("traced_amount","Traced amount"),
        ("first_event","First event"),("last_event","Last event")
    ])
    delay_table = table(delay_rows, [
        ("delay_minutes","Extra delay (min)"),("case_id","Case ID"),
        ("priority_rank","Priority rank"),("intervention_time","Intervention time"),
        ("funds_at_risk","Funds at risk"),("funds_remaining","Funds remaining"),
        ("pct_remaining","Remaining (%)")
    ])
    view_table = table(views, [("name","View"),("n_records","Records visible")])

    delay_points = []
    for r in delay_rows:
        try:
            delay_points.append((float(r.get("delay_minutes", 0)), float(r.get("pct_remaining", 0))))
        except Exception:
            pass
    delay_points.sort()
    if delay_points:
        xmax = max(x for x, _ in delay_points) or 1
        coords = " ".join(
            f"{40 + x/xmax*700:.1f},{180 - max(0,min(100,y))*1.4:.1f}"
            for x, y in delay_points
        )
        circles = "".join(
            f"<circle cx='{40+x/xmax*700:.1f}' cy='{180-max(0,min(100,y))*1.4:.1f}' r='3'/>"
            for x, y in delay_points
        )
        chart = f"""<svg viewBox='0 0 780 220' role='img' aria-label='Simulated funds remaining versus response delay'>
        <line x1='40' y1='180' x2='740' y2='180' stroke='#63718b'/>
        <line x1='40' y1='40' x2='40' y2='180' stroke='#63718b'/>
        <polyline points='{coords}' fill='none' stroke='#67e8c2' stroke-width='3'/>
        {circles}
        <text x='40' y='205' fill='#aab8d0' font-size='11'>0 min</text>
        <text x='740' y='205' text-anchor='end' fill='#aab8d0' font-size='11'>{xmax:g} min</text>
        <text x='10' y='30' fill='#aab8d0' font-size='11'>100%</text>
        <text x='10' y='178' fill='#aab8d0' font-size='11'>0%</text>
        </svg>"""
    else:
        chart = "<p class='muted'>No delay data available.</p>"

    assumptions_html = "".join(f"<li>{esc(a)}</li>" for a in assumptions)
    if not assumptions_html:
        assumptions_html = "<li>Assumptions not present in saved results.</li>"

    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>TraceFlow Z | Investigation Console</title>
<style>
:root{{color-scheme:dark;--bg:#080d18;--panel:#111a2b;--line:#293750;--muted:#aab8d0;--mint:#67e8c2;--text:#edf4ff}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font:14px/1.5 system-ui, sans-serif}}
header{{padding:25px clamp(16px,4vw,48px);border-bottom:1px solid var(--line);background:#0c1424}}
.brand{{color:var(--mint);font-weight:800;letter-spacing:2px;font-size:12px}}
h1{{font-size:clamp(25px,4vw,38px);margin:8px 0}}h2{{font-size:18px;margin:0 0 16px}}
p{{color:var(--muted)}}main{{max-width:1450px;margin:auto;padding:24px clamp(12px,3vw,36px) 50px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(165px,1fr));gap:12px}}
.card,section{{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:16px;min-width:0}}
.metric{{font-size:27px;font-weight:750;margin-top:5px}}.muted,.sub{{color:var(--muted);font-size:12px}}
.layout{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr));gap:16px}}
.tablewrap{{overflow:auto;max-width:100%}}table{{border-collapse:collapse;width:100%;font-size:12px;white-space:nowrap}}
th,td{{text-align:left;padding:9px 11px;border-bottom:1px solid var(--line)}}th{{color:var(--mint);background:#17243a;position:sticky;top:0}}
select,button{{background:#17243a;color:var(--text);border:1px solid #3b4b68;border-radius:8px;padding:10px;font:inherit}}
button{{cursor:pointer}}label{{display:block;color:var(--muted);margin-bottom:6px}}
.barrow{{display:grid;grid-template-columns:155px 1fr 48px;gap:10px;align-items:center;margin:14px 0;font-size:12px}}
.bar{{height:10px;background:#26334a;border-radius:10px;overflow:hidden}}.bar i{{display:block;height:100%;background:var(--mint)}}
svg{{width:100%;height:auto}}.warning{{border-left:3px solid #f2c879;padding-left:14px}}
footer{{color:var(--muted);font-size:12px;padding:12px 0}}a{{color:var(--mint)}}
@media(max-width:500px){{.barrow{{grid-template-columns:115px 1fr 40px}}}}
</style></head><body>
<header><div class="brand">TRACEFLOW Z / INVESTIGATION CONSOLE</div>
<h1>Cross-bank suspicious trail analysis</h1>
<p>Privacy-aware synthetic investigation prototype · Saved experiment results</p>
<form><label for="mode">Visibility mode</label><select name="mode" id="mode" onchange="this.form.submit()">{options}</select></form>
</header><main>
<div class="grid">
<div class="card"><div class="sub">Flagged cases</div><div class="metric">{esc(selected.get('flagged_cases','—'))}</div></div>
<div class="card"><div class="sub">Precision</div><div class="metric">{pct(selected.get('precision'))}</div></div>
<div class="card"><div class="sub">Recall</div><div class="metric">{pct(selected.get('recall'))}</div></div>
<div class="card"><div class="sub">Trail coverage</div><div class="metric">{pct(selected.get('trail_coverage'))}</div></div>
<div class="card"><div class="sub">False-positive rate</div><div class="metric">{pct(selected.get('false_positive_rate'))}</div></div>
<div class="card"><div class="sub">Analysis latency</div><div class="metric">{number(selected.get('latency_ms'))} ms</div></div>
</div>
<section><h2>Visibility mode comparison</h2>
{table(overview,[("mode","Mode"),("flagged_cases","Flagged"),("precision","Precision"),("recall","Recall"),("trail_coverage","Trail coverage"),("false_positive_rate","False-positive rate"),("latency_ms","Latency (ms)")])}
<h2 style="margin-top:22px">Trail coverage by mode</h2>{bars}</section>
<section><h2>Ranked investigation cases</h2>
<p>Scores prioritize synthetic cases for review; they are not proof of fraud.</p>{case_table}</section>
<section><h2>Response-delay simulation</h2>
<p>Selected mode: <b>{esc(LABELS[mode])}</b>. Values are simulated, not actual recoveries.</p>{chart}{delay_table}</section>
<div class="layout"><section><h2>Permitted data views</h2>{view_table}</section>
<section><h2>Simulation assumptions</h2><ul>{assumptions_html}</ul></section></div>
<section class="warning"><h2>Privacy, safety and limitations</h2>
<ul>
<li>All data is synthetic; no real bank, customer or transaction is accessed.</li>
<li>A risk score is not proof of fraud and must never trigger enforcement automatically.</li>
<li>Selected signals are not differential privacy, federated learning or cryptographic privacy. Tokens, timing, bank IDs and amounts may still reveal information.</li>
<li>Metrics depend on the synthetic scenario and evaluation rules; they are not real-world performance predictions.</li>
<li>Funds remaining are simulated under stated assumptions, not actual recoveries.</li>
<li>Latency is measured on this machine. No IBM Z performance advantage is claimed.</li>
</ul></section>
<footer>TraceFlow Z · Local saved results · <button onclick="location.reload()">Refresh results</button></footer>
</main></body></html>"""

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        query = parse_qs(urlparse(self.path).query)
        body = page(query).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))

if __name__ == "__main__":
    print("TraceFlow Z results dashboard")
    print("Reading saved results from:", OUT)
    print("Listening on http://127.0.0.1:8512")
    HTTPServer(("127.0.0.1", 8512), Handler).serve_forever()
