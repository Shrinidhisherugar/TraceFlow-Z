from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import csv
import json
import html
import os

ROOT = Path.cwd()
DATA_DIRS = [ROOT / "data", ROOT / "outputs"]

def csv_files():
    files = []
    for folder in DATA_DIRS:
        if folder.exists():
            files.extend(folder.rglob("*.csv"))
    return sorted(set(f.resolve() for f in files))

def read_csv(path):
    with path.open("r", newline="", encoding="utf-8-sig", errors="replace") as f:
        reader = csv.DictReader(f)
        columns = reader.fieldnames or []
        rows = []
        for i, row in enumerate(reader):
            if i >= 500:
                break
            rows.append({str(k): str(v or "") for k, v in row.items() if k is not None})
    return columns, rows

def page():
    files = csv_files()
    cards = []
    for p in files:
        try:
            cols, rows = read_csv(p)
            cards.append({
                "name": str(p.relative_to(ROOT)),
                "columns": cols,
                "rows": rows,
                "count": len(rows)
            })
        except Exception as e:
            cards.append({"name": p.name, "columns": [], "rows": [],
                          "count": 0, "error": str(e)})
    payload = json.dumps(cards).replace("</", "<\\/")
    return r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>TraceFlow Z | Investigation Console</title>
<style>
:root{color-scheme:dark;--bg:#080d18;--panel:#111a2b;--line:#24324a;
--muted:#9cabc3;--cyan:#54e1d0;--blue:#7ca9ff;--white:#edf3ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--white);
font:14px/1.5 system-ui,Segoe UI,sans-serif}
header{padding:24px 5%;border-bottom:1px solid var(--line);
background:linear-gradient(110deg,#101d34,#0b1220)}
.brand{color:var(--cyan);font-size:12px;font-weight:800;letter-spacing:3px}
h1{margin:7px 0;font-size:clamp(25px,4vw,38px)}
p{color:var(--muted)}main{max-width:1400px;margin:auto;padding:25px 5%}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:14px;
padding:18px;margin-bottom:18px;min-width:0}
.kicker{font-size:11px;color:var(--muted);letter-spacing:1.5px;text-transform:uppercase}
.big{font-size:30px;font-weight:750;margin-top:7px;color:var(--cyan)}
h2{font-size:17px;margin:0 0 12px}
button,select,input{background:#0b1322;color:var(--white);border:1px solid #344661;
border-radius:8px;padding:10px;max-width:100%}
button{cursor:pointer}button:hover{border-color:var(--cyan)}
.controls{display:flex;gap:10px;flex-wrap:wrap;margin:14px 0}
.tablewrap{overflow:auto;max-height:430px;border:1px solid var(--line);border-radius:8px}
table{border-collapse:collapse;width:100%;font-size:12px;white-space:nowrap}
th,td{text-align:left;padding:9px 12px;border-bottom:1px solid var(--line);max-width:300px;
overflow:hidden;text-overflow:ellipsis}
th{position:sticky;top:0;background:#18253a;color:var(--cyan)}
.empty{border:1px dashed #344661;border-radius:10px;padding:22px;color:var(--muted)}
footer{color:var(--muted);padding:20px 0;font-size:12px}
</style></head><body>
<header><div class="brand">TRACEFLOW Z / LINUXONE</div>
<h1>Fraud Investigation Console</h1>
<p>Cross-bank transaction analysis · Synthetic data · Local CSV explorer</p>
</header><main>
<div class="grid">
<div class="panel"><div class="kicker">Data files found</div><div class="big" id="fileCount">0</div></div>
<div class="panel"><div class="kicker">Rows available to preview</div><div class="big" id="rowCount">0</div></div>
<div class="panel"><div class="kicker">Dashboard status</div><div class="big" style="font-size:21px">ONLINE</div><p>Standard Python server</p></div>
</div>
<section class="panel"><h2>Transaction data explorer</h2>
<p>Choose a CSV file to inspect its columns and records. Each preview is limited to 500 rows.</p>
<div class="controls"><select id="fileSelect"></select>
<input id="filter" placeholder="Filter visible rows…">
<button onclick="render()">Refresh view</button></div>
<div id="tableArea" class="empty">Loading local data…</div>
</section>
<section class="panel"><h2>Visibility modes</h2>
<div class="grid">
<div><b>LOCAL_ONLY</b><p>Each simulated bank sees its own records.</p></div>
<div><b>SELECTED_SIGNALS</b><p>Compare results with selected shared signals, where implemented in the project outputs.</p></div>
<div><b>FULL_NETWORK_BENCHMARK</b><p>Full-information comparison; not a proposed deployment mode.</p></div>
</div>
</section>
<footer>TraceFlow Z prototype · Synthetic data only · No real bank connection or fund freezing.
<br>CSV previews show saved outputs; they do not independently rerun the fraud simulation.</footer>
</main>
<script>
const data = PAYLOAD;
const sel=document.getElementById('fileSelect');
const area=document.getElementById('tableArea');
document.getElementById('fileCount').textContent=data.length;
document.getElementById('rowCount').textContent=data.reduce((n,x)=>n+x.count,0);
if(!data.length){
 sel.innerHTML='<option>No CSV files found</option>';
 area.innerHTML='No CSV files found under data/ or outputs/. Generate the project data first, then refresh this page.';
}else{
 data.forEach((d,i)=>{const o=document.createElement('option');o.value=i;o.textContent=d.name+' ('+d.count+' rows)';sel.appendChild(o)});
}
function render(){
 if(!data.length)return;
 const d=data[Number(sel.value)||0], q=document.getElementById('filter').value.toLowerCase();
 const rows=d.rows.filter(r=>Object.values(r).some(v=>String(v).toLowerCase().includes(q)));
 if(!d.columns.length){area.textContent=d.error||'This CSV has no header row.';return}
 const table=document.createElement('table'),thead=document.createElement('thead'),tr=document.createElement('tr');
 d.columns.forEach(c=>{const th=document.createElement('th');th.textContent=c;tr.appendChild(th)});
 thead.appendChild(tr);table.appendChild(thead);
 const tb=document.createElement('tbody');
 rows.forEach(r=>{const tr=document.createElement('tr');d.columns.forEach(c=>{const td=document.createElement('td');td.textContent=r[c]||'';td.title=r[c]||'';tr.appendChild(td)});tb.appendChild(tr)});
 table.appendChild(tb);area.replaceChildren();
 const summary=document.createElement('p');summary.textContent=`${rows.length} matching rows · ${d.columns.length} columns`;area.appendChild(summary);
 const wrap=document.createElement('div');wrap.className='tablewrap';wrap.appendChild(table);area.appendChild(wrap);
}
sel.addEventListener('change',render);document.getElementById('filter').addEventListener('input',render);render();
</script></body></html>""".replace("PAYLOAD", payload)

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        if path not in ("/", "/index.html"):
            self.send_error(404)
            return
        body = page().encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))

print("TraceFlow Z fallback dashboard")
print("Project:", ROOT)
print("CSV files found:", len(csv_files()))
print("Listening on http://127.0.0.1:8511")
HTTPServer(("127.0.0.1", 8511), Handler).serve_forever()
