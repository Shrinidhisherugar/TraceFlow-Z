"""Teammate 3 - visibility modes and evaluation against SEPARATE ground truth.

Public API
----------
VisibilityMode, MODES, VisibilityConfig, MODE_DESCRIPTIONS, SHARED_SIGNAL_FIELDS
tokenize_account / tokenize_transactions
build_views(transactions, mode, config)        -> list of {"name", "transactions"}
run_visibility_mode(transactions, mode, ...)   -> {"mode", "views", "cases", "analysis_ms"}
evaluate_cases(cases, ground_truth, accounts, ...) -> metrics dict

All three modes receive the SAME transactions and are scored by the SAME evaluation rules.
Only ``evaluate_cases`` reads ground truth; nothing upstream of it ever sees a label.

Visibility rules (also documented in docs/architecture.md)
-----------------------------------------------------------
LOCAL_ONLY          Each bank sees every transfer it sends or receives (``sender_or_receiver``,
                    or only those it sends with ``sender_only``) and analyses that view alone.
SELECTED_SIGNALS    Each bank still analyses its own local view, AND a shared pool contains only
                    "signal records": cross-bank transfers of at least ``signal_min_amount``,
                    exposing the fields in SHARED_SIGNAL_FIELDS.  Intra-bank transfers of other
                    banks, channel and scenario_id are never shared.  Not a formal privacy guarantee.
FULL_NETWORK_BENCHMARK  The engine sees every transfer (comparison benchmark only).
"""
from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from enum import Enum

import pandas as pd

from .contracts import (TRACE_REQUIRED_COLUMNS, ContractError, case_transaction_set,
                        truth_transaction_set, validate_accounts, validate_transactions)
from .graph_tracing import TracingConfig, trace_suspicious_paths

DEFAULT_SALT = "traceflow-z-demo-salt"


class VisibilityMode(str, Enum):
    LOCAL_ONLY = "LOCAL_ONLY"
    SELECTED_SIGNALS = "SELECTED_SIGNALS"
    FULL_NETWORK_BENCHMARK = "FULL_NETWORK_BENCHMARK"


MODES = tuple(m.value for m in VisibilityMode)

MODE_DESCRIPTIONS = {
    "LOCAL_ONLY": "Each bank analyses only transfers it sends or receives; no information is exchanged.",
    "SELECTED_SIGNALS": ("Banks analyse their own records and additionally pool predefined "
                         "cross-bank signal records (see shared fields). Not a formal privacy guarantee."),
    "FULL_NETWORK_BENCHMARK": "The engine sees every synthetic transfer. Benchmark only, not a deployment model.",
}

# Every field a bank shares in SELECTED_SIGNALS, and what it could still reveal.
SHARED_SIGNAL_FIELDS = {
    "transaction_id": ("opaque reference used to link records", "equal ids reveal the same transfer was reported"),
    "timestamp": ("event time", "exact timing can be correlated with outside information"),
    "from_account": ("salted-hash account token", "stable token lets recipients follow one account across all signals"),
    "to_account": ("salted-hash account token", "same; reveals who an account pays"),
    "from_bank": ("sending bank id", "reveals which banks an account's counterparties use"),
    "to_bank": ("receiving bank id", "same"),
    "amount": ("amount rounded to 2 significant figures", "magnitude of the transfer remains visible"),
}
NOT_SHARED_FIELDS = ("channel", "scenario_id", "intra-bank transfers of other banks",
                     "cross-bank transfers below signal_min_amount")


@dataclass(frozen=True)
class VisibilityConfig:
    local_rule: str = "sender_or_receiver"   # or "sender_only"
    signal_min_amount: float = 5000.0
    salt: str = DEFAULT_SALT

    def __post_init__(self):
        if self.local_rule not in ("sender_or_receiver", "sender_only"):
            raise ValueError("local_rule must be 'sender_or_receiver' or 'sender_only'")
        if self.signal_min_amount < 0:
            raise ValueError("signal_min_amount must be non-negative")


def tokenize_account(account_id, salt=DEFAULT_SALT):
    digest = hashlib.sha256(f"{salt}|{account_id}".encode()).hexdigest()[:10]
    return f"TOK_{digest}"


def tokenize_transactions(transactions, salt=DEFAULT_SALT):
    df = transactions.copy()
    cache = {}
    for col in ("from_account", "to_account"):
        df[col] = [cache.setdefault(a, tokenize_account(a, salt)) for a in df[col].astype(str)]
    return df


def _parse_mode(mode):
    try:
        return VisibilityMode(mode)
    except ValueError as exc:
        raise ContractError(f"unknown visibility mode {mode!r}; expected one of {MODES}") from exc


def _local_view(tx, bank, rule):
    mask = tx["from_bank"] == bank
    if rule == "sender_or_receiver":
        mask = mask | (tx["to_bank"] == bank)
    return tx[mask]


def build_views(transactions, mode, config=None):
    """Return the permitted views for ``mode``: list of {"name", "transactions"} (tokenised)."""
    cfg = config or VisibilityConfig()
    mode = _parse_mode(mode)
    validate_transactions(transactions, full_schema=False)
    base = tokenize_transactions(transactions[TRACE_REQUIRED_COLUMNS], cfg.salt)
    if mode is VisibilityMode.FULL_NETWORK_BENCHMARK:
        return [{"name": "FULL_NETWORK", "transactions": base}]
    banks = sorted(set(base["from_bank"]) | set(base["to_bank"]))
    views = [{"name": f"LOCAL:{b}", "transactions": _local_view(base, b, cfg.local_rule)} for b in banks]
    if mode is VisibilityMode.SELECTED_SIGNALS:
        pooled = base[(base["from_bank"] != base["to_bank"]) &
                      (pd.to_numeric(base["amount"]) >= cfg.signal_min_amount)].copy()
        pooled["amount"] = [float(f"{a:.2g}") for a in pd.to_numeric(pooled["amount"])]
        views.append({"name": "POOLED_SIGNALS", "transactions": pooled})
    return views


def merge_case_lists(case_lists):
    """Union of cases from several views; drop any case whose transactions are a subset of another."""
    flat = [c for lst in case_lists for c in lst]
    flat.sort(key=lambda c: (-len(c["ordered_transaction_ids"]), -c["risk_score"], c["case_id"]))
    kept, kept_sets = [], []
    for c in flat:
        s = set(c["ordered_transaction_ids"])
        if any(s <= k for k in kept_sets):
            continue
        kept.append(c)
        kept_sets.append(s)
    kept.sort(key=lambda c: (-c["risk_score"], c["case_id"]))
    return kept


def run_visibility_mode(transactions, mode, tracing_config=None, visibility_config=None):
    """Build the mode's views, trace each view independently and merge the cases."""
    t0 = time.perf_counter()
    views = build_views(transactions, mode, visibility_config)
    case_lists = [trace_suspicious_paths(v["transactions"], tracing_config) for v in views]
    cases = merge_case_lists(case_lists)
    return {"mode": _parse_mode(mode).value,
            "views": [{"name": v["name"], "n_records": int(len(v["transactions"]))} for v in views],
            "cases": cases,
            "analysis_ms": (time.perf_counter() - t0) * 1000.0}


def _ratio(num, den):
    return None if den == 0 else num / den


def evaluate_cases(cases, ground_truth, accounts, salt=DEFAULT_SALT, overlap_threshold=0.5,
                   latency_ms=None):
    """Compute metrics for predicted ``cases`` against SEPARATE ``ground_truth``.

    Definitions (tau = overlap_threshold, default 0.5)
      flagged case          every case returned by the pipeline (risk >= tracing threshold)
      purity(case)          |case tx  INTERSECT  all planted-suspicious tx| / |case tx|
      true-positive case    purity >= tau          -> precision = TP cases / flagged cases
      planted case detected |planted tx INTERSECT union of flagged tx| / |planted tx| >= tau
                                                   -> recall = detected / planted suspicious cases
      trail coverage        |planted-suspicious tx recovered| / |planted-suspicious tx|
      false-positive rate   legitimate accounts appearing in any flagged case / all legitimate
                            accounts, where legitimate = not in any planted-suspicious case
      look-alike flag rate  legitimate look-alike cases covered (>= tau) by flagged tx / look-alikes
      recommendation latency  supplied by the caller (measured wall-clock), never invented
    A ratio with a zero denominator is returned as None (not applicable), never as 0 or 1.
    """
    if not 0 < overlap_threshold <= 1:
        raise ValueError("overlap_threshold must be in (0, 1]")
    validate_accounts(accounts)
    if not isinstance(ground_truth, dict) or "cases" not in ground_truth:
        raise ContractError("ground_truth must be a dict with a 'cases' list")
    truth = ground_truth["cases"]
    suspicious = [t for t in truth if t.get("kind") == "SUSPICIOUS"]
    lookalikes = [t for t in truth if t.get("kind") == "LEGIT_LOOKALIKE"]
    for t in truth:
        truth_transaction_set(t)   # validates the ground-truth interface (key 'transaction_ids')

    flagged_sets = [case_transaction_set(c) for c in cases]   # validates 'ordered_transaction_ids'
    planted_all = set().union(*(truth_transaction_set(t) for t in suspicious)) if suspicious else set()
    flagged_union = set().union(*flagged_sets) if flagged_sets else set()

    tp_cases = sum(1 for s in flagged_sets if len(s & planted_all) / len(s) >= overlap_threshold)
    detected = sum(1 for t in suspicious
                   if len(truth_transaction_set(t) & flagged_union) / len(truth_transaction_set(t))
                   >= overlap_threshold)
    looked_flagged = sum(1 for t in lookalikes
                         if len(truth_transaction_set(t) & flagged_union) / len(truth_transaction_set(t))
                         >= overlap_threshold)

    suspicious_accounts = {a for t in suspicious for a in t["accounts"]}
    legit_tokens = {tokenize_account(a, salt) for a in accounts["account_id"]
                    if a not in suspicious_accounts}
    flagged_tokens = {tok for c in cases for tok in c["suspicious_account_tokens"]}
    fp_accounts = flagged_tokens & legit_tokens

    return {
        "n_flagged_cases": len(cases), "n_true_positive_cases": tp_cases,
        "n_false_positive_cases": len(cases) - tp_cases,
        "n_planted_cases": len(suspicious), "n_planted_detected": detected,
        "precision": _ratio(tp_cases, len(cases)),
        "recall": _ratio(detected, len(suspicious)),
        "trail_coverage": _ratio(len(planted_all & flagged_union), len(planted_all)),
        "false_positive_rate": _ratio(len(fp_accounts), len(legit_tokens)),
        "n_legit_accounts": len(legit_tokens), "n_legit_accounts_flagged": len(fp_accounts),
        "lookalike_flag_rate": _ratio(looked_flagged, len(lookalikes)),
        "n_lookalikes": len(lookalikes), "n_lookalikes_flagged": looked_flagged,
        "recommendation_latency_ms": latency_ms,
        "overlap_threshold": overlap_threshold,
    }
