"""Streamlit dashboard. Run with:  python main.py dashboard   (or streamlit run src/dashboard_app.py)

Every number and chart comes from ``dashboard_helpers.run_pipeline``; nothing is computed or
invented here.  Tables are rendered as escaped HTML so that pyarrow is NOT required.
"""
import sys
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd             # noqa: E402
import plotly.graph_objects as go   # noqa: E402
import streamlit as st              # noqa: E402

from src.dashboard_helpers import (PipelineConfig, cases_table, delay_table, html_table,  # noqa: E402
                                   metrics_table, run_pipeline, trail_edges, trail_layout)
from src.graph_tracing import TracingConfig  # noqa: E402
from src.visibility_evaluation import (MODE_DESCRIPTIONS, MODES, NOT_SHARED_FIELDS,  # noqa: E402
                                       SHARED_SIGNAL_FIELDS, VisibilityConfig)

st.set_page_config(page_title="TraceFlow Z", layout="wide")
st.title("TraceFlow Z - privacy-aware cross-bank fraud investigation (synthetic data)")
st.caption("Synthetic data only. Risk scores are investigation aids, not proof of fraud. "
           "No real accounts are frozen and no real funds are recovered.")

with st.sidebar:
    st.header("Scenario")
    seed = st.number_input("Random seed", 0, 10_000_000, 42)
    per_bank = st.number_input("Accounts per bank", 20, 300, 40)
    background = st.number_input("Background transactions", 100, 5000, 600, step=100)
    n_susp = st.number_input("Planted suspicious cases", 1, 8, 4)
    n_look = st.number_input("Legitimate look-alike cases", 0, 8, 3)
    st.header("Tracing")
    max_gap = st.slider("Max wait before forwarding (min)", 15, 1440, 720)
    min_risk = st.slider("Flag threshold (risk score)", 0, 100, 50)
    sig_min = st.number_input("Signal sharing minimum amount", 0, 100000, 5000, step=500)
    st.header("Response simulation")
    handling = st.slider("Handling time per case (min)", 0, 240, 30)
    investigators = st.number_input("Investigators", 1, 10, 1)
    window = st.slider("Cash-out window (min)", 15, 1440, 120)
    policy = st.selectbox("Queue policy", ["priority", "fifo"])
    delays = st.multiselect("Delays to compare (min)", [0, 15, 30, 60, 120, 240, 480, 1440],
                            default=[0, 15, 30, 60, 120, 240, 480, 1440])
    run = st.button("Run analysis")

config = PipelineConfig(
    seed=int(seed), accounts_per_bank=int(per_bank), background_transactions=int(background),
    n_suspicious=int(n_susp), n_lookalikes=int(n_look),
    tracing=TracingConfig(max_gap_minutes=float(max_gap), min_risk_score=float(min_risk)),
    visibility=VisibilityConfig(signal_min_amount=float(sig_min)),
    delays_minutes=tuple(sorted(delays)) or (0,), handling_minutes=float(handling),
    n_investigators=int(investigators), cashout_window_minutes=float(window), queue_policy=policy)

if run or "results" not in st.session_state:
    try:
        st.session_state["results"] = run_pipeline(config)
        st.session_state["error"] = None
    except Exception as exc:    # show the real error instead of a blank page
        st.session_state["error"] = f"{type(exc).__name__}: {exc}"
if st.session_state.get("error"):
    st.error(st.session_state["error"])
    st.stop()
results = st.session_state["results"]
cfg = results["config"]

tab_net, tab_cases, tab_vis, tab_delay, tab_lim = st.tabs(
    ["Network", "Ranked cases & trails", "Visibility comparison", "Response delay", "Assumptions & limits"])

with tab_net:
    tx, acc = results["transactions"], results["accounts"]
    c1, c2, c3 = st.columns(3)
    c1.metric("Accounts", len(acc))
    c2.metric("Transactions", len(tx))
    c3.metric("Cross-bank transfers", int((tx["from_bank"] != tx["to_bank"]).sum()))
    st.markdown("**Transactions per bank pair**")
    pairs = tx.groupby(["from_bank", "to_bank"]).size().reset_index(name="transfers")
    st.markdown(html_table(pairs), unsafe_allow_html=True)
    st.markdown("**Sample transactions** (ground-truth labels are stored separately and not shown)")
    st.markdown(html_table(tx.head(25)), unsafe_allow_html=True)

with tab_cases:
    mode = st.selectbox("Visibility mode", MODES, index=len(MODES) - 1, key="case_mode")
    st.caption(MODE_DESCRIPTIONS[mode])
    cases = results["modes"][mode]["cases"]
    if not cases:
        st.info("No cases were flagged in this mode.")
    else:
        st.markdown(html_table(cases_table(cases)), unsafe_allow_html=True)
        pick = st.selectbox("Inspect case", [c["case_id"] for c in cases])
        case = next(c for c in cases if c["case_id"] == pick)
        st.markdown("**Why this case was flagged**")
        for reason in case["risk_reasons"] + case["priority_reasons"]:
            st.write("- " + reason)
        edges = trail_edges(case, results["transactions"], cfg.visibility.salt)
        pos = trail_layout(edges)
        fig = go.Figure()
        for e in edges:
            (x0, y0, _), (x1, y1, _) = pos[e["from"]], pos[e["to"]]
            fig.add_trace(go.Scatter(x=[x0, x1], y=[y0, y1], mode="lines",
                                     line=dict(width=2), hoverinfo="text", showlegend=False,
                                     text=f"{e['transaction_id']} {e['amount']:,.2f} {e['timestamp']}"))
        fig.add_trace(go.Scatter(
            x=[p[0] for p in pos.values()], y=[p[1] for p in pos.values()], mode="markers+text",
            text=[f"{n[-6:]}<br>{p[2]}" for n, p in pos.items()], textposition="top center",
            marker=dict(size=14), showlegend=False))
        fig.update_layout(title="Traced path (account tokens, left to right in time order)",
                          xaxis=dict(visible=False), yaxis=dict(visible=False), height=380)
        st.plotly_chart(fig)
        st.markdown(html_table(pd.DataFrame(edges)), unsafe_allow_html=True)

with tab_vis:
    st.markdown("Same transactions, same scenarios, same evaluation rules in every mode.")
    mt = metrics_table(results)
    st.markdown(html_table(mt), unsafe_allow_html=True)
    fig = go.Figure()
    for metric in ("precision", "recall", "trail_coverage", "false_positive_rate"):
        fig.add_trace(go.Bar(name=metric, x=list(mt["mode"]),
                             y=[0 if v is None or v != v else v for v in mt[metric]]))
    fig.update_layout(barmode="group", yaxis_title="value (0-1; n/a plotted as 0)", height=380)
    st.plotly_chart(fig)
    st.markdown("**Fields shared in SELECTED_SIGNALS** (and what they could still reveal)")
    rows = ["| field | shared as | possible leakage |", "|---|---|---|"]
    rows += [f"| {k} | {v[0]} | {v[1]} |" for k, v in SHARED_SIGNAL_FIELDS.items()]
    st.markdown("\n".join(rows))
    st.write("Never shared: " + ", ".join(NOT_SHARED_FIELDS))

with tab_delay:
    st.markdown(f"Queue policy: **{cfg.queue_policy}**, handling {cfg.handling_minutes:g} min, "
                f"{cfg.n_investigators} investigator(s), cash-out window {cfg.cashout_window_minutes:g} min.")
    fig = go.Figure()
    for m in MODES:
        dt = delay_table(results["modes"][m]["simulation"])
        fig.add_trace(go.Scatter(name=m, x=dt["delay_minutes"], mode="lines+markers",
                                 y=[0 if v is None or v != v else v for v in dt["pct_remaining"]]))
    fig.update_layout(xaxis_title="response delay (min)", height=380,
                      yaxis_title="simulated funds remaining for intervention (%)")
    st.plotly_chart(fig)
    mode_d = st.selectbox("Mode details", MODES, index=len(MODES) - 1, key="delay_mode")
    st.markdown(html_table(delay_table(results["modes"][mode_d]["simulation"])), unsafe_allow_html=True)
    for line in results["modes"][mode_d]["simulation"]["assumptions"]:
        st.write("- " + line)

with tab_lim:
    st.markdown(
        "- All data is synthetic; no real bank, customer or transaction is accessed.\n"
        "- A risk score is not proof of fraud and must never trigger enforcement automatically.\n"
        "- SELECTED_SIGNALS is not differential privacy, federated learning or cryptographic privacy; "
        "shared tokens, timings, bank ids and amounts can still leak information.\n"
        "- Metrics depend on the synthetic scenario design and the stated overlap rule (0.5); "
        "they are not predictions of real-world performance.\n"
        "- Funds-remaining values are simulated under the listed assumptions, not actual recoveries.\n"
        "- Latency is measured on this machine; no IBM Z performance advantage is claimed.")
