"""Teammate 2 - directed transaction graph, bounded multi-hop tracing, explainable risk.

Public API
----------
TracingConfig                      - tunable, documented thresholds (same config for every mode)
build_transaction_graph(tx)        -> networkx.MultiDiGraph (accounts = nodes, transfers = edges)
trace_suspicious_paths(tx, config) -> list[case dict]  (shared case output contract)
score_case(features)               -> (risk_score 0-100, [readable reasons])

Algorithm: every transfer can start a trail.  A trail is extended with an outgoing transfer
of the receiving account when (a) it happens no earlier than the incoming transfer and within
``max_gap_minutes`` of it, (b) the account has not been visited (cycle-safe), and (c) the
forwarded amount is between ``min_retention`` and ``max_growth`` times the incoming amount
(money is passed on, not created).  Maximal trails with at least ``min_hops`` transfers are
merged into cases when they share a transaction.  Only the 7 tracing columns are read;
``channel``/``scenario_id`` and any label are never features (label columns are rejected).
"""
from __future__ import annotations

import hashlib
import statistics
from dataclasses import dataclass

import networkx as nx
import pandas as pd

from .contracts import TRACE_REQUIRED_COLUMNS, validate_transactions


class TracingLimitError(RuntimeError):
    """Raised when path enumeration exceeds ``TracingConfig.max_paths`` (config too loose)."""


@dataclass(frozen=True)
class TracingConfig:
    max_hops: int = 6                 # longest trail considered (transfers)
    min_hops: int = 3                 # shortest trail reported as multi-hop
    max_gap_minutes: float = 720.0    # max wait between receiving and forwarding
    min_retention: float = 0.30       # forwarded / incoming lower bound
    max_growth: float = 1.10          # forwarded / incoming upper bound (tolerates banding)
    min_amount: float = 1000.0        # ignore transfers below this amount
    min_risk_score: float = 50.0      # cases below this are not reported ("flagged" threshold)
    max_paths: int = 100000           # safety valve against combinatorial blow-up

    def __post_init__(self):
        if not 1 <= self.min_hops <= self.max_hops:
            raise ValueError("need 1 <= min_hops <= max_hops")
        if self.max_gap_minutes < 0 or self.min_amount < 0:
            raise ValueError("max_gap_minutes and min_amount must be non-negative")
        if not 0 < self.min_retention <= self.max_growth:
            raise ValueError("need 0 < min_retention <= max_growth")
        if not 0 <= self.min_risk_score <= 100:
            raise ValueError("min_risk_score must be within 0-100")


def _prepare(transactions):
    validate_transactions(transactions, full_schema=False)
    df = transactions[TRACE_REQUIRED_COLUMNS].copy()
    if df.empty:
        df["ts_dt"] = pd.Series(dtype="datetime64[ns]")
        return df
    df["transaction_id"] = df["transaction_id"].astype(str)
    df["amount"] = pd.to_numeric(df["amount"])
    df["ts_dt"] = pd.to_datetime(df["timestamp"], format="ISO8601")
    return df


def build_transaction_graph(transactions):
    """Directed multigraph: nodes = accounts (attr ``bank``), edges keyed by transaction_id."""
    df = _prepare(transactions)
    graph = nx.MultiDiGraph()
    for r in df.itertuples(index=False):
        graph.add_node(r.from_account, bank=r.from_bank)
        graph.add_node(r.to_account, bank=r.to_bank)
        graph.add_edge(r.from_account, r.to_account, key=r.transaction_id,
                       transaction_id=r.transaction_id, ts=r.ts_dt, timestamp=r.timestamp,
                       amount=float(r.amount), from_bank=r.from_bank, to_bank=r.to_bank)
    return graph


def _enumerate_paths(graph, cfg):
    out = {}
    for u in graph.nodes:
        edges = [(d["ts"], tid, u, v, d["amount"])
                 for _, v, tid, d in graph.out_edges(u, keys=True, data=True)]
        edges.sort(key=lambda e: (e[0], e[1]))
        out[u] = edges
    gap = pd.Timedelta(minutes=cfg.max_gap_minutes)
    paths = []

    def extend(path, visited):
        last = path[-1]
        extended = False
        if len(path) < cfg.max_hops:
            for edge in out.get(last[3], ()):
                ts, _tid, _u, v, amt = edge
                if ts < last[0]:
                    continue
                if ts - last[0] > gap:
                    break
                if v in visited or amt < cfg.min_amount:
                    continue
                ratio = amt / last[4]
                if ratio < cfg.min_retention or ratio > cfg.max_growth:
                    continue
                extended = True
                extend(path + [edge], visited | {v})
        if not extended and len(path) >= cfg.min_hops:
            paths.append(path)
            if len(paths) > cfg.max_paths:
                raise TracingLimitError(
                    f"more than {cfg.max_paths} trails; tighten max_gap_minutes/min_retention")

    for u in graph.nodes:
        for edge in out[u]:
            if edge[4] >= cfg.min_amount:
                extend([edge], {edge[2], edge[3]})
    return paths


def _fmt(x):
    return f"{x:,.2f}"


def score_case(f):
    """Explainable additive score (max 100). ``f`` is the feature dict built in this module."""
    pts, reasons = 0.0, []
    p = min(20.0, 5.0 * f["trail_depth"])
    pts += p
    reasons.append(f"Trail of {f['trail_depth']} consecutive transfers (+{p:.0f})")
    p = min(20.0, 7.0 * f["bank_crossings"])
    pts += p
    reasons.append(f"{f['bank_crossings']} cross-bank transfer(s) across {len(f['banks'])} bank(s): "
                   f"{', '.join(f['banks'])} (+{p:.0f})")
    gap = f["median_gap_minutes"]
    if gap is None:
        p, why = 0.0, "no onward-transfer timing available"
    elif gap <= 15:
        p, why = 25.0, "very rapid onward transfer"
    elif gap <= 60:
        p, why = 18.0, "rapid onward transfer"
    elif gap <= 180:
        p, why = 10.0, "moderately quick onward transfer"
    else:
        p, why = 4.0, "slow onward transfer"
    pts += p
    if gap is not None:
        reasons.append(f"Median wait before forwarding {gap:.1f} min - {why} (+{p:.0f})")
    ret = f["median_retention"]
    if ret is None:
        p = 0.0
    else:
        p = 15.0 if ret >= 0.9 else 8.0 if ret >= 0.6 else 3.0
        reasons.append(f"Median {ret * 100:.0f}% of each incoming amount is forwarded (+{p:.0f})")
    pts += p
    amt = f["origin_amount"]
    p = 20.0 if amt >= 50000 else 14.0 if amt >= 20000 else 8.0 if amt >= 10000 else 3.0
    pts += p
    reasons.append(f"Amount entering the trail {_fmt(amt)} (+{p:.0f})")
    reasons.append("Investigation aid only - not proof of fraud")
    return round(min(100.0, pts), 1), reasons


class _UnionFind:
    def __init__(self):
        self.parent = {}

    def find(self, x):
        self.parent.setdefault(x, x)
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a, b):
        self.parent[self.find(a)] = self.find(b)


def trace_suspicious_paths(transactions, config=None):
    """Trace bounded multi-hop trails and return cases (shared case output contract).

    Returns a list of dicts sorted by ``risk_score`` (desc) with the fields
    case_id, suspicious_account_tokens, ordered_transaction_ids, banks_involved,
    total_traced_amount, risk_score, risk_reasons, first_event_time, last_event_time plus
    origin_amount, bank_crossings, trail_depth, n_transactions.  Empty input -> [].
    """
    cfg = config or TracingConfig()
    graph = build_transaction_graph(transactions)
    if graph.number_of_edges() == 0:
        return []
    info = {tid: (d["ts"], u, v, d["amount"], d["from_bank"], d["to_bank"], d["timestamp"])
            for u, v, tid, d in graph.edges(keys=True, data=True)}
    paths = _enumerate_paths(graph, cfg)
    if not paths:
        return []

    uf = _UnionFind()
    for path in paths:
        for e in path[1:]:
            uf.union(path[0][1], e[1])
        uf.find(path[0][1])
    groups = {}
    for path in paths:
        groups.setdefault(uf.find(path[0][1]), []).append(path)

    cases = []
    for group in groups.values():
        tids = sorted({e[1] for p in group for e in p}, key=lambda t: (info[t][0], t))
        depth = max(len(p) for p in group)
        pair_gaps, pair_ratios = {}, {}
        for p in group:
            for a, b in zip(p, p[1:]):
                pair_gaps[(a[1], b[1])] = (b[0] - a[0]).total_seconds() / 60.0
                pair_ratios[(a[1], b[1])] = b[4] / a[4]
        recs = [info[t] for t in tids]
        receivers = {r[2] for r in recs}
        origin = sum(r[3] for r in recs if r[1] not in receivers) or max(r[3] for r in recs)
        tokens, seen = [], set()
        for r in recs:
            for acct in (r[1], r[2]):
                if acct not in seen:
                    seen.add(acct)
                    tokens.append(acct)
        banks = sorted({b for r in recs for b in (r[4], r[5])})
        crossings = sum(r[4] != r[5] for r in recs)
        feats = {"trail_depth": depth, "bank_crossings": crossings, "banks": banks,
                 "median_gap_minutes": statistics.median(pair_gaps.values()) if pair_gaps else None,
                 "median_retention": statistics.median(pair_ratios.values()) if pair_ratios else None,
                 "origin_amount": origin}
        score, reasons = score_case(feats)
        if score < cfg.min_risk_score:
            continue
        digest = hashlib.sha1("|".join(tids).encode()).hexdigest()[:8].upper()
        cases.append({
            "case_id": f"CASE-{digest}", "suspicious_account_tokens": tokens,
            "ordered_transaction_ids": tids, "banks_involved": banks,
            "total_traced_amount": round(sum(r[3] for r in recs), 2),
            "risk_score": score, "risk_reasons": reasons,
            "first_event_time": recs[0][6], "last_event_time": recs[-1][6],
            "origin_amount": round(origin, 2), "bank_crossings": crossings,
            "trail_depth": depth, "n_transactions": len(tids)})
    cases.sort(key=lambda c: (-c["risk_score"], c["case_id"]))
    return cases
