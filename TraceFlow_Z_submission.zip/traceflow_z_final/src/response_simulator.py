"""Teammate 4 - explainable case prioritisation and response-delay simulation.

Public API
----------
rank_cases(cases, weights=None)                       -> new list of cases + priority fields
simulate_response(cases, transactions, ...)           -> {"assumptions", "parameters", "per_case", "summary"}

Inputs are predicted cases that follow the shared contract (``ordered_transaction_ids``) and
the transaction table that holds those ids.  Neither function can see ground truth.

DOCUMENTED SYNTHETIC ASSUMPTIONS (also returned in ``result["assumptions"]``)
  A1  A case becomes alertable when its last traced transfer happens (``last_event_time``).
  A2  ``delay`` is extra minutes before an investigator can start; investigators then work
      through the queue, each case taking ``handling_minutes``.  Scheduling is time-ordered,
      work-conserving and non-preemptive: whenever an investigator is free it takes the waiting
      alert with the best ``priority_rank`` (or the earliest alert under ``fifo``).
      Intervention happens when handling ends.
  A3  "Funds at risk" = amounts of terminal transfers in the trail (transfers whose receiving
      account does not forward the money again inside the trail).
  A4  Terminal funds are fully interceptable until they arrive, then drain linearly to zero
      over ``cashout_window_minutes`` (a stated assumption, not measured behaviour).
  A5  Results are SIMULATED potential funds remaining for intervention - never real recoveries.
"""
from __future__ import annotations

import math
from copy import deepcopy

import pandas as pd

from .contracts import CASE_TX_KEY, ContractError, validate_case

DEFAULT_WEIGHTS = {"risk": 0.60, "amount": 0.25, "urgency": 0.15}
DEFAULT_DELAYS = (0, 15, 30, 60, 120, 240, 480, 1440)


def rank_cases(cases, weights=None):
    """Rank cases by an explainable priority score (0-100).

    priority = w_risk*risk_score + w_amount*amount_score + w_urgency*urgency_score
      amount_score  100 * log(1+total_traced_amount) / log(1+largest amount in this case set)
      urgency_score 100 * (1 - trail_duration_minutes/1440) clipped to [0,100]; faster trails
                    are more time-critical.
    Returns copies of the cases (inputs are not mutated) with priority_rank, priority_score,
    priority_reasons, sorted by rank.
    """
    w = dict(DEFAULT_WEIGHTS if weights is None else weights)
    if set(w) != set(DEFAULT_WEIGHTS) or any(v < 0 for v in w.values()) or sum(w.values()) <= 0:
        raise ValueError(f"weights must be non-negative with keys {sorted(DEFAULT_WEIGHTS)}")
    total_w = sum(w.values())
    cases = list(cases)
    for c in cases:
        validate_case(c)
    if not cases:
        return []
    biggest = max(math.log1p(c["total_traced_amount"]) for c in cases) or 1.0
    ranked = []
    for c in cases:
        out = deepcopy(c)
        duration = (pd.Timestamp(c["last_event_time"]) - pd.Timestamp(c["first_event_time"])
                    ).total_seconds() / 60.0
        amount_score = 100.0 * math.log1p(c["total_traced_amount"]) / biggest
        urgency = max(0.0, min(100.0, 100.0 * (1.0 - duration / 1440.0)))
        score = (w["risk"] * c["risk_score"] + w["amount"] * amount_score
                 + w["urgency"] * urgency) / total_w
        out["priority_score"] = round(score, 1)
        out["priority_reasons"] = [
            f"Risk score {c['risk_score']:.1f} (weight {w['risk'] / total_w:.2f})",
            f"Traced amount {c['total_traced_amount']:,.2f} -> amount score {amount_score:.0f} "
            f"(weight {w['amount'] / total_w:.2f})",
            f"Trail lasted {duration:.0f} min -> urgency {urgency:.0f} (weight {w['urgency'] / total_w:.2f})"]
        ranked.append(out)
    ranked.sort(key=lambda c: (-c["priority_score"], c["case_id"]))
    for i, c in enumerate(ranked, start=1):
        c["priority_rank"] = i
    return ranked


def _case_funds(case, lookup):
    """Terminal transfers of a case: list of (timestamp, amount)."""
    ids = case[CASE_TX_KEY]
    missing = [i for i in ids if i not in lookup.index]
    if missing:
        raise ContractError(f"case {case['case_id']} references unknown transaction ids {missing[:3]}")
    rows = lookup.loc[ids]
    terminals = []
    for tid, r in rows.iterrows():
        forwarded = ((rows["from_account"] == r["to_account"]) & (rows["ts"] >= r["ts"])).any()
        if not forwarded:
            terminals.append((r["ts"], float(r["amount"])))
    return terminals


def simulate_response(cases, transactions, delays_minutes=DEFAULT_DELAYS, handling_minutes=30.0,
                      n_investigators=1, cashout_window_minutes=120.0, queue_policy="priority"):
    """Simulate how response delay affects the (simulated) funds still available to intervene on."""
    delays = [float(d) for d in delays_minutes]
    if not delays or any(d < 0 for d in delays):
        raise ValueError("delays_minutes must be a non-empty list of non-negative numbers")
    if handling_minutes < 0 or cashout_window_minutes <= 0 or int(n_investigators) < 1:
        raise ValueError("handling_minutes>=0, cashout_window_minutes>0, n_investigators>=1 required")
    if queue_policy not in ("priority", "fifo"):
        raise ValueError("queue_policy must be 'priority' or 'fifo'")
    cases = list(cases)
    for c in cases:
        validate_case(c)
        if queue_policy == "priority" and "priority_rank" not in c:
            raise ContractError("queue_policy='priority' needs cases from rank_cases() "
                                "(missing 'priority_rank')")
    for col in ("transaction_id", "timestamp", "from_account", "to_account", "amount"):
        if col not in transactions.columns:
            raise ContractError(f"transactions is missing column {col!r}")
    lookup = transactions[["transaction_id", "timestamp", "from_account", "to_account", "amount"]].copy()
    lookup["ts"] = pd.to_datetime(lookup["timestamp"], format="ISO8601")
    lookup = lookup.set_index("transaction_id")

    info = []
    for c in cases:
        terminals = _case_funds(c, lookup)
        info.append({"case": c, "terminals": terminals,
                     "alert": pd.Timestamp(c["last_event_time"]),
                     "at_risk": sum(a for _, a in terminals)})

    per_case, summary = [], []
    window = float(cashout_window_minutes)
    for delay in delays:
        free = [pd.Timestamp.min] * int(n_investigators)
        pending = [dict(item, ready=item["alert"] + pd.Timedelta(minutes=delay)) for item in info]
        total_risk = total_left = 0.0
        while pending:
            k = min(range(len(free)), key=lambda j: (free[j], j))
            t = max(free[k], min(p["ready"] for p in pending))
            waiting = [p for p in pending if p["ready"] <= t]
            if queue_policy == "priority":
                item = min(waiting, key=lambda p: (p["case"]["priority_rank"], p["case"]["case_id"]))
            else:
                item = min(waiting, key=lambda p: (p["ready"], p["case"]["case_id"]))
            pending.remove(item)
            ready, start = item["ready"], t
            finish = start + pd.Timedelta(minutes=float(handling_minutes))
            free[k] = finish
            left = 0.0
            for ts, amount in item["terminals"]:
                drained = max(0.0, (finish - ts).total_seconds() / 60.0)
                left += amount * max(0.0, 1.0 - drained / window)
            total_risk += item["at_risk"]
            total_left += left
            per_case.append({
                "delay_minutes": delay, "case_id": item["case"]["case_id"],
                "priority_rank": item["case"].get("priority_rank"),
                "intervention_time": finish.isoformat(timespec="seconds"),
                "queue_wait_minutes": round((start - ready).total_seconds() / 60.0, 1),
                "funds_at_risk": round(item["at_risk"], 2), "funds_remaining": round(left, 2),
                "pct_remaining": None if item["at_risk"] == 0 else round(100.0 * left / item["at_risk"], 1)})
        summary.append({"delay_minutes": delay, "n_cases": len(info),
                        "funds_at_risk": round(total_risk, 2),
                        "funds_remaining": round(total_left, 2),
                        "pct_remaining": None if total_risk == 0 else round(100.0 * total_left / total_risk, 1)})
    return {
        "assumptions": [
            "A1 A case is alertable when its last traced transfer occurs (last_event_time).",
            "A2 Delay is extra minutes before an investigator can start; investigators then take cases "
            f"in '{queue_policy}' order, {handling_minutes:g} min each, {int(n_investigators)} in parallel "
            "(work-conserving, non-preemptive: a free investigator takes the best waiting alert). Intervention happens when handling ends.",
            "A3 Funds at risk = amounts of terminal transfers (receiver does not forward inside the trail).",
            f"A4 Terminal funds are interceptable until they arrive, then drain linearly to zero over "
            f"{cashout_window_minutes:g} min (assumption, not measured).",
            "A5 Results are SIMULATED potential funds remaining for intervention, not actual recoveries."],
        "parameters": {"delays_minutes": delays, "handling_minutes": float(handling_minutes),
                       "n_investigators": int(n_investigators),
                       "cashout_window_minutes": float(cashout_window_minutes),
                       "queue_policy": queue_policy},
        "per_case": per_case, "summary": summary}
