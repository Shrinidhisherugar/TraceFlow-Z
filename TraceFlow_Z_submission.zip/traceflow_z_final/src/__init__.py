"""TraceFlow Z - privacy-aware cross-bank fraud investigation simulation (synthetic data only)."""
__version__ = "1.0.0"
