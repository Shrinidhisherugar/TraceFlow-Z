"""Teammate 1 - reproducible synthetic data for three simulated banks.

Public API
----------
generate_dataset(seed=42, ...) -> (accounts_df, transactions_df, ground_truth)
save_dataset(directory, accounts, transactions, ground_truth)
load_dataset(directory) -> (accounts_df, transactions_df, ground_truth)

``transactions_df`` follows the shared schema.  ``ground_truth`` is a SEPARATE dict used
only by evaluation.  Transaction ids are assigned AFTER a global time sort so that id order
does not reveal which transactions belong to planted scenarios, and ``scenario_id`` is the
same value for every row (it names the test run, not the planted label).
"""
from __future__ import annotations

import json
import random
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

from .contracts import ACCOUNT_COLUMNS, BANKS, TRANSACTION_COLUMNS, validate_dataset

SCENARIO_ID = "SCENARIO_01"
SUSPICIOUS_PATTERNS = ("CHAIN", "BRANCH")
LOOKALIKE_PATTERNS = ("ESCROW", "MERCHANT", "FAMILY")
CHANNELS = ("UPI", "NEFT", "IMPS", "BANK_TRANSFER")


def _accounts(accounts_per_bank):
    rows = []
    for bank, prefix in zip(BANKS, "ABC"):
        rows.extend((f"{prefix}{i:03d}", bank) for i in range(1, accounts_per_bank + 1))
    return rows


def generate_dataset(seed=42, accounts_per_bank=40, background_transactions=600,
                     n_suspicious=4, n_lookalikes=3, start="2026-10-01T00:00:00", days=14):
    """Generate accounts, transactions and (separate) ground truth. Deterministic per seed."""
    if accounts_per_bank < 10 or background_transactions < 0 or days < 3:
        raise ValueError("accounts_per_bank>=10, background_transactions>=0, days>=3 required")
    if n_suspicious < 0 or n_lookalikes < 0:
        raise ValueError("scenario counts must be non-negative")
    acct_rows = _accounts(accounts_per_bank)
    needed = 6 * n_suspicious + 4 * n_lookalikes
    if 2 * needed > len(acct_rows):
        raise ValueError("too many planted scenarios for this number of accounts")

    rng = random.Random(seed)
    t0 = datetime.fromisoformat(start)
    bank_of = dict(acct_rows)
    all_ids = [a for a, _ in acct_rows]
    pool = list(all_ids)           # accounts not yet used by a planted scenario
    rows = []                       # dicts with private keys _ts and _row

    def add(frm, to, ts, amount, channel):
        rows.append({"from_account": frm, "from_bank": bank_of[frm], "to_account": to,
                     "to_bank": bank_of[to], "amount": round(float(amount), 2),
                     "channel": channel, "_ts": ts, "_row": len(rows)})
        return len(rows) - 1

    def pick_nodes(n_nodes, hops, require_split):
        for _ in range(1000):
            nodes = rng.sample(pool, n_nodes)
            pairs = [(nodes[a], nodes[b]) for a, b in hops]
            crossings = sum(bank_of[x] != bank_of[y] for x, y in pairs)
            if crossings < 2:
                continue
            if require_split:   # no single bank may be a party to every hop
                if any(all(b in (bank_of[x], bank_of[y]) for x, y in pairs) for b in BANKS):
                    continue
            for n in nodes:
                pool.remove(n)
            return nodes
        raise RuntimeError("could not place a scenario; use more accounts")

    def start_time():
        return t0 + timedelta(days=rng.uniform(0.5, days - 1.5))

    truth_cases = []   # holds row indexes until ids are assigned

    def record(kind, pattern, row_ids, nodes):
        truth_cases.append({"kind": kind, "pattern": pattern, "_rows": row_ids,
                            "accounts": sorted(nodes)})

    # ---- planted suspicious scenarios ---------------------------------------------------
    for i in range(n_suspicious):
        pattern = SUSPICIOUS_PATTERNS[i % len(SUSPICIOUS_PATTERNS)]
        ts, amt = start_time(), rng.uniform(20000, 90000)
        ch = rng.choice(("UPI", "IMPS"))
        if pattern == "CHAIN":
            n_hops = rng.choice((4, 5))
            nodes = pick_nodes(n_hops + 1, [(k, k + 1) for k in range(n_hops)], True)
            ids = []
            for k in range(n_hops):
                ids.append(add(nodes[k], nodes[k + 1], ts, amt, ch))
                ts += timedelta(minutes=rng.uniform(2, 40))
                amt *= rng.uniform(0.93, 0.99)
        else:   # BRANCH: v -> m1 -> m2 -> (m3 -> c) and a side leg m2 -> d
            nodes = pick_nodes(6, [(0, 1), (1, 2), (2, 3), (3, 4), (2, 5)], True)
            v, m1, m2, m3, c, d = nodes
            ids = [add(v, m1, ts, amt, ch)]
            ts += timedelta(minutes=rng.uniform(2, 30)); held = amt * rng.uniform(0.94, 0.98)
            ids.append(add(m1, m2, ts, held, ch))
            ts += timedelta(minutes=rng.uniform(2, 30)); held *= rng.uniform(0.94, 0.98)
            side, main = held * rng.uniform(0.35, 0.42), held * rng.uniform(0.55, 0.60)
            ids.append(add(m2, d, ts, side, ch))
            ts += timedelta(minutes=rng.uniform(2, 20))
            ids.append(add(m2, m3, ts, main, ch))
            ts += timedelta(minutes=rng.uniform(2, 30))
            ids.append(add(m3, c, ts, main * rng.uniform(0.94, 0.98), ch))
        record("SUSPICIOUS", pattern, ids, nodes)

    # ---- legitimate look-alikes (same shape, different tempo/size) -----------------------
    specs = {"ESCROW": ((15000, 60000), (60, 180), (0.985, 1.0)),
             "MERCHANT": ((5000, 30000), (240, 600), (0.97, 0.995)),
             "FAMILY": ((3000, 8000), (15, 45), (0.98, 1.0))}
    for i in range(n_lookalikes):
        pattern = LOOKALIKE_PATTERNS[i % len(LOOKALIKE_PATTERNS)]
        (lo, hi), (gap_lo, gap_hi), (m_lo, m_hi) = specs[pattern]
        nodes = pick_nodes(4, [(0, 1), (1, 2), (2, 3)], False)
        ts, amt, ids = start_time(), rng.uniform(lo, hi), []
        ch = rng.choice(("BANK_TRANSFER", "UPI", "NEFT"))
        for k in range(3):
            ids.append(add(nodes[k], nodes[k + 1], ts, amt, ch))
            ts += timedelta(minutes=rng.uniform(gap_lo, gap_hi))
            amt *= rng.uniform(m_lo, m_hi)
        record("LEGIT_LOOKALIKE", pattern, ids, nodes)

    # ---- background legitimate activity ---------------------------------------------------
    for _ in range(background_transactions):
        frm, to = rng.sample(all_ids, 2)
        amount = min(max(rng.lognormvariate(7.5, 1.0), 100.0), 40000.0)
        add(frm, to, t0 + timedelta(days=rng.uniform(0, days)), amount, rng.choice(CHANNELS))

    # ---- assign ids after a global time sort ----------------------------------------------
    order = sorted(range(len(rows)), key=lambda i: (rows[i]["_ts"], rows[i]["_row"]))
    new_id = {old: f"TX{n:06d}" for n, old in enumerate(order, start=1)}
    records = []
    for old in order:
        r = rows[old]
        records.append({"transaction_id": new_id[old],
                        "timestamp": r["_ts"].isoformat(timespec="seconds"),
                        "from_account": r["from_account"], "from_bank": r["from_bank"],
                        "to_account": r["to_account"], "to_bank": r["to_bank"],
                        "amount": r["amount"], "channel": r["channel"], "scenario_id": SCENARIO_ID})
    transactions = pd.DataFrame(records, columns=TRANSACTION_COLUMNS)
    accounts = pd.DataFrame(acct_rows, columns=ACCOUNT_COLUMNS)

    cases = []
    for n, tc in enumerate(truth_cases, start=1):
        tx_ids = sorted(new_id[r] for r in tc["_rows"])
        banks = sorted({bank_of[a] for a in tc["accounts"]})
        cases.append({"truth_id": f"GT{n:03d}", "kind": tc["kind"], "pattern": tc["pattern"],
                      "transaction_ids": tx_ids, "accounts": tc["accounts"], "banks": banks})
    ground_truth = {"schema_version": 1, "seed": seed, "cases": cases}
    validate_dataset(accounts, transactions)
    return accounts, transactions, ground_truth


def save_dataset(directory, accounts, transactions, ground_truth):
    """Write accounts.csv, transactions.csv and the SEPARATE ground_truth.json."""
    out = Path(directory)
    out.mkdir(parents=True, exist_ok=True)
    accounts.to_csv(out / "accounts.csv", index=False)
    transactions.to_csv(out / "transactions.csv", index=False)
    (out / "ground_truth.json").write_text(json.dumps(ground_truth, indent=2))
    return out


def load_dataset(directory):
    src = Path(directory)
    accounts = pd.read_csv(src / "accounts.csv", dtype=str)
    transactions = pd.read_csv(src / "transactions.csv", dtype={
        "transaction_id": str, "timestamp": str, "from_account": str, "from_bank": str,
        "to_account": str, "to_bank": str, "channel": str, "scenario_id": str})
    ground_truth = json.loads((src / "ground_truth.json").read_text())
    validate_dataset(accounts, transactions)
    return accounts, transactions, ground_truth


if __name__ == "__main__":
    a, t, g = generate_dataset()
    print(f"{len(a)} accounts, {len(t)} transactions, {len(g['cases'])} planted cases")
