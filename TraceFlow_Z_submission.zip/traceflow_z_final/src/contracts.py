"""Shared data contracts for TraceFlow Z (owned by the integration owner).

This module imports nothing from the rest of ``src`` so it can never take part in a
circular import.  Every other module validates its inputs/outputs against it.

Interface decision (the ``ordered_transaction_ids`` / ``transaction_ids`` question)
---------------------------------------------------------------------------------
* PREDICTED cases (tracing -> ranking -> simulation -> evaluation) carry
  ``ordered_transaction_ids``: a list, ordered by (timestamp, transaction_id).
* GROUND-TRUTH cases (evaluation only) carry ``transaction_ids``: an unordered set label.
Both are read ONLY through ``case_transaction_set`` / ``truth_transaction_set`` below,
which raise a clear error if the wrong key is supplied.  No adapter is needed anywhere.
"""
from __future__ import annotations

import pandas as pd

BANKS = ("BANK_A", "BANK_B", "BANK_C")

TRANSACTION_COLUMNS = [
    "transaction_id", "timestamp", "from_account", "from_bank",
    "to_account", "to_bank", "amount", "channel", "scenario_id",
]
# Tracing/visibility only need these; channel and scenario_id are never used as features.
TRACE_REQUIRED_COLUMNS = [
    "transaction_id", "timestamp", "from_account", "from_bank",
    "to_account", "to_bank", "amount",
]
ACCOUNT_COLUMNS = ["account_id", "bank_id"]

CASE_REQUIRED_FIELDS = (
    "case_id", "suspicious_account_tokens", "ordered_transaction_ids", "banks_involved",
    "total_traced_amount", "risk_score", "risk_reasons", "first_event_time", "last_event_time",
)
CASE_TX_KEY = "ordered_transaction_ids"
TRUTH_TX_KEY = "transaction_ids"
TRUTH_KINDS = ("SUSPICIOUS", "LEGIT_LOOKALIKE")

# Column names that would smuggle ground truth into model inputs.
LABEL_COLUMN_NAMES = frozenset({
    "is_suspicious", "is_fraud", "label", "labels", "ground_truth", "truth_id",
    "truth_kind", "kind", "planted", "planted_case", "pattern",
})


class ContractError(ValueError):
    """Raised when data or an interface violates the agreed TraceFlow Z contract."""


def require_columns(df, columns, name="DataFrame"):
    if not isinstance(df, pd.DataFrame):
        raise ContractError(f"{name} must be a pandas DataFrame, got {type(df).__name__}")
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise ContractError(f"{name} is missing required columns: {missing}")


def reject_label_columns(df, name="DataFrame"):
    leaked = sorted(set(df.columns) & LABEL_COLUMN_NAMES)
    if leaked:
        raise ContractError(f"{name} contains ground-truth/label columns {leaked}; "
                            "labels must never be model inputs")


def validate_transactions(df, full_schema=True):
    """Validate a transaction table. ``full_schema=False`` checks only the tracing columns."""
    cols = TRANSACTION_COLUMNS if full_schema else TRACE_REQUIRED_COLUMNS
    require_columns(df, cols, "transactions")
    reject_label_columns(df, "transactions")
    if df.empty:
        return
    core = df[TRACE_REQUIRED_COLUMNS]
    if core.isnull().any().any():
        raise ContractError("transactions contain null values in required columns")
    if df["transaction_id"].astype(str).duplicated().any():
        raise ContractError("transaction_id values must be unique")
    amounts = pd.to_numeric(df["amount"], errors="coerce")
    if amounts.isnull().any() or (amounts <= 0).any():
        raise ContractError("amount must be numeric and strictly positive")
    try:
        pd.to_datetime(df["timestamp"], errors="raise", format="ISO8601")
    except (ValueError, TypeError) as exc:
        raise ContractError(f"timestamp must be ISO 8601: {exc}") from exc
    if (df["from_account"].astype(str) == df["to_account"].astype(str)).any():
        raise ContractError("self-transfers (from_account == to_account) are not allowed")


def validate_accounts(df):
    require_columns(df, ACCOUNT_COLUMNS, "accounts")
    reject_label_columns(df, "accounts")
    if df["account_id"].duplicated().any():
        raise ContractError("account_id values must be unique")
    if df[ACCOUNT_COLUMNS].isnull().any().any():
        raise ContractError("accounts contain null values")


def validate_dataset(accounts, transactions):
    validate_accounts(accounts)
    validate_transactions(transactions, full_schema=True)
    bank_of = dict(zip(accounts["account_id"], accounts["bank_id"]))
    for acc_col, bank_col in (("from_account", "from_bank"), ("to_account", "to_bank")):
        for acc, bank in zip(transactions[acc_col], transactions[bank_col]):
            if acc not in bank_of:
                raise ContractError(f"transaction references unknown account {acc!r}")
            if bank_of[acc] != bank:
                raise ContractError(f"account {acc!r} is in {bank_of[acc]} but transaction says {bank}")


def validate_case(case):
    """Validate one predicted case against the shared case output contract."""
    if not isinstance(case, dict):
        raise ContractError(f"case must be a dict, got {type(case).__name__}")
    if CASE_TX_KEY not in case:
        hint = (f" (found '{TRUTH_TX_KEY}', which is the ground-truth key; predicted cases "
                f"must use '{CASE_TX_KEY}')") if TRUTH_TX_KEY in case else ""
        raise ContractError(f"case is missing '{CASE_TX_KEY}'{hint}")
    missing = [f for f in CASE_REQUIRED_FIELDS if f not in case]
    if missing:
        raise ContractError(f"case is missing fields: {missing}")
    ids = case[CASE_TX_KEY]
    if not isinstance(ids, (list, tuple)) or not ids or not all(isinstance(i, str) for i in ids):
        raise ContractError(f"{CASE_TX_KEY} must be a non-empty list of strings")
    score = case["risk_score"]
    if not isinstance(score, (int, float)) or not 0 <= score <= 100:
        raise ContractError("risk_score must be a number within 0-100")
    if not isinstance(case["risk_reasons"], list):
        raise ContractError("risk_reasons must be a list of strings")
    if pd.Timestamp(case["first_event_time"]) > pd.Timestamp(case["last_event_time"]):
        raise ContractError("first_event_time must not be after last_event_time")


def validate_truth_case(truth_case):
    """Validate one ground-truth case (evaluation module only)."""
    if not isinstance(truth_case, dict):
        raise ContractError("ground-truth case must be a dict")
    if TRUTH_TX_KEY not in truth_case:
        hint = (f" (found '{CASE_TX_KEY}', which is the predicted-case key)"
                if CASE_TX_KEY in truth_case else "")
        raise ContractError(f"ground-truth case is missing '{TRUTH_TX_KEY}'{hint}")
    if truth_case.get("kind") not in TRUTH_KINDS:
        raise ContractError(f"ground-truth 'kind' must be one of {TRUTH_KINDS}")
    for key in ("truth_id", "accounts"):
        if key not in truth_case:
            raise ContractError(f"ground-truth case is missing '{key}'")


def case_transaction_set(case):
    """Transaction-id set of a PREDICTED case (reads ``ordered_transaction_ids``)."""
    validate_case(case)
    return frozenset(case[CASE_TX_KEY])


def truth_transaction_set(truth_case):
    """Transaction-id set of a GROUND-TRUTH case (reads ``transaction_ids``)."""
    validate_truth_case(truth_case)
    return frozenset(truth_case[TRUTH_TX_KEY])
