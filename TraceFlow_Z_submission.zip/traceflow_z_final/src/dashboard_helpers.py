"""Teammate 5 / integration owner - end-to-end pipeline and display helpers.

``run_pipeline`` is the single entry point used by main.py, the tests and the dashboard.  It
calls the real modules in the agreed order and returns only values they computed:

  data_generator -> contracts validation -> visibility_evaluation (views + tracing)
  -> response_simulator.rank_cases -> evaluate_cases (+ measured latency)
  -> response_simulator.simulate_response

This file imports no Streamlit/Plotly, so it is testable anywhere.
"""
from __future__ import annotations

import html
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import pandas as pd

from .contracts import validate_dataset
from .data_generator import generate_dataset
from .graph_tracing import TracingConfig
from .response_simulator import DEFAULT_DELAYS, rank_cases, simulate_response
from .visibility_evaluation import (MODES, VisibilityConfig, evaluate_cases, run_visibility_mode,
                                    tokenize_transactions)


@dataclass(frozen=True)
class PipelineConfig:
    seed: int = 42
    accounts_per_bank: int = 40
    background_transactions: int = 600
    n_suspicious: int = 4
    n_lookalikes: int = 3
    tracing: TracingConfig = field(default_factory=TracingConfig)
    visibility: VisibilityConfig = field(default_factory=VisibilityConfig)
    delays_minutes: tuple = DEFAULT_DELAYS
    handling_minutes: float = 30.0
    n_investigators: int = 1
    cashout_window_minutes: float = 120.0
    queue_policy: str = "priority"


def run_pipeline(config=None, dataset=None):
    """Run generation (or use ``dataset``), all three visibility modes, ranking, evaluation, simulation."""
    cfg = config or PipelineConfig()
    if dataset is None:
        dataset = generate_dataset(seed=cfg.seed, accounts_per_bank=cfg.accounts_per_bank,
                                   background_transactions=cfg.background_transactions,
                                   n_suspicious=cfg.n_suspicious, n_lookalikes=cfg.n_lookalikes)
    accounts, transactions, ground_truth = dataset
    validate_dataset(accounts, transactions)

    modes = {}
    for mode in MODES:
        t0 = time.perf_counter()
        analysis = run_visibility_mode(transactions, mode, cfg.tracing, cfg.visibility)
        ranked = rank_cases(analysis["cases"])
        latency_ms = (time.perf_counter() - t0) * 1000.0       # measured, end to end
        metrics = evaluate_cases(ranked, ground_truth, accounts, salt=cfg.visibility.salt,
                                 latency_ms=latency_ms)
        sim_args = dict(delays_minutes=cfg.delays_minutes, handling_minutes=cfg.handling_minutes,
                        n_investigators=cfg.n_investigators,
                        cashout_window_minutes=cfg.cashout_window_minutes)
        simulation = simulate_response(ranked, transactions, queue_policy=cfg.queue_policy, **sim_args)
        other = "fifo" if cfg.queue_policy == "priority" else "priority"
        comparison = simulate_response(ranked, transactions, queue_policy=other, **sim_args)
        modes[mode] = {"views": analysis["views"], "cases": ranked, "metrics": metrics,
                       "simulation": simulation, "comparison_policy": other,
                       "comparison_simulation": comparison}
    return {"config": cfg, "accounts": accounts, "transactions": transactions,
            "ground_truth": ground_truth, "modes": modes}


# --------------------------------------------------------------------------- display helpers
def cases_table(cases):
    rows = [{"rank": c.get("priority_rank"), "case_id": c["case_id"], "priority": c.get("priority_score"),
             "risk_score": c["risk_score"], "banks": ", ".join(c["banks_involved"]),
             "transfers": c.get("n_transactions", len(c["ordered_transaction_ids"])),
             "depth": c.get("trail_depth"), "traced_amount": c["total_traced_amount"],
             "first_event": c["first_event_time"], "last_event": c["last_event_time"]} for c in cases]
    return pd.DataFrame(rows)


def metrics_table(results):
    rows = []
    for mode, m in results["modes"].items():
        x = m["metrics"]
        rows.append({"mode": mode, "flagged_cases": x["n_flagged_cases"],
                     "precision": x["precision"], "recall": x["recall"],
                     "trail_coverage": x["trail_coverage"], "false_positive_rate": x["false_positive_rate"],
                     "lookalikes_flagged": f"{x['n_lookalikes_flagged']}/{x['n_lookalikes']}",
                     "latency_ms": x["recommendation_latency_ms"]})
    return pd.DataFrame(rows)


def delay_table(simulation):
    return pd.DataFrame(simulation["summary"])


def trail_edges(case, transactions, salt):
    """Edges of a case (tokenised accounts) for drawing, in the case's own order."""
    tok = tokenize_transactions(transactions, salt).set_index("transaction_id")
    rows = tok.loc[case["ordered_transaction_ids"]]
    return [{"transaction_id": tid, "from": r["from_account"], "to": r["to_account"],
             "from_bank": r["from_bank"], "to_bank": r["to_bank"], "amount": float(r["amount"]),
             "timestamp": r["timestamp"]} for tid, r in rows.iterrows()]


def trail_layout(edges):
    """Simple layered layout: x = hop depth, y = slot within the layer."""
    depth, bank = {}, {}
    for e in edges:
        bank[e["from"]], bank[e["to"]] = e["from_bank"], e["to_bank"]
        depth.setdefault(e["from"], 0)
        depth[e["to"]] = max(depth.get(e["to"], 0), depth[e["from"]] + 1)
    layers = {}
    for node, d in sorted(depth.items(), key=lambda kv: (kv[1], kv[0])):
        layers.setdefault(d, []).append(node)
    return {n: (d, i - (len(nodes) - 1) / 2.0, bank[n])
            for d, nodes in layers.items() for i, n in enumerate(nodes)}


def format_value(v):
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return "n/a"
    if isinstance(v, float):
        return f"{v:.3f}" if abs(v) <= 1.0 else f"{v:,.1f}"
    return str(v)


def html_table(df, max_rows=200):
    """Escaped HTML table (avoids st.dataframe, which needs pyarrow)."""
    if df is None or df.empty:
        return "<p><em>No rows.</em></p>"
    head = "".join(f"<th style='text-align:left;padding:2px 8px'>{html.escape(str(c))}</th>" for c in df.columns)
    body = []
    for _, row in df.head(max_rows).iterrows():
        cells = "".join(f"<td style='padding:2px 8px'>{html.escape(format_value(v))}</td>" for v in row)
        body.append(f"<tr>{cells}</tr>")
    return ("<div style='overflow-x:auto'><table style='border-collapse:collapse;font-size:0.85rem'>"
            f"<thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table></div>")


def write_outputs(results, out_dir):
    """Write machine-readable results (JSON/CSV) of an actual run."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    summary = {mode: {"metrics": m["metrics"], "views": m["views"], "delay_summary": m["simulation"]["summary"],
                      "assumptions": m["simulation"]["assumptions"]} for mode, m in results["modes"].items()}
    (out / "results.json").write_text(json.dumps(summary, indent=2, default=str))
    metrics_table(results).to_csv(out / "metrics.csv", index=False)
    for mode, m in results["modes"].items():
        cases_table(m["cases"]).to_csv(out / f"cases_{mode}.csv", index=False)
        pd.DataFrame(m["simulation"]["per_case"]).to_csv(out / f"delay_{mode}.csv", index=False)
    (out / "config.json").write_text(json.dumps(asdict(results["config"]), indent=2, default=str))
    return out
