#!/usr/bin/env python3
"""TraceFlow Z integration entry point (run from the project root).

  python main.py check-env                 environment/architecture/package/port report
  python main.py generate                  write data/accounts.csv, transactions.csv, ground_truth.json
  python main.py run                       full pipeline, prints real metrics, writes outputs/
  python main.py test                      run the unittest suite
  python main.py dashboard [--port N|auto] [--background]
  python main.py status | stop             inspect / stop ONLY the dashboard started by this project
"""
import argparse
import importlib
import json
import os
import platform
import socket
import subprocess
import sys
import time
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

PID_FILE = ROOT / "run" / "dashboard.pid"
APP = ROOT / "src" / "dashboard_app.py"
PORT_RANGE = range(8511, 8600)       # avoids 8502 (old project) and 38888 (Jupyter)


def port_is_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def find_free_port():
    for p in PORT_RANGE:
        if port_is_free(p):
            return p
    raise RuntimeError("no free port in 8511-8599")


def cmd_check_env(_):
    print(f"python        {sys.version.split()[0]}  ({sys.executable})")
    print(f"architecture  {platform.machine()}  ({platform.system()})")
    for mod in ("pandas", "numpy", "networkx", "plotly", "streamlit", "pyarrow"):
        try:
            m = importlib.import_module(mod)
            print(f"{mod:<13} OK {getattr(m, '__version__', '?')}")
        except Exception as exc:
            tag = "optional, not required" if mod == "pyarrow" else "MISSING"
            print(f"{mod:<13} {tag} ({type(exc).__name__})")
    print(f"free port     {find_free_port()}")


def cmd_generate(args):
    from src.data_generator import generate_dataset, save_dataset
    a, t, g = generate_dataset(seed=args.seed)
    out = save_dataset(ROOT / "data", a, t, g)
    print(f"wrote {out}/accounts.csv ({len(a)} rows), transactions.csv ({len(t)} rows), ground_truth.json")


def cmd_run(args):
    from src.dashboard_helpers import (PipelineConfig, cases_table, delay_table, metrics_table,
                                       run_pipeline, write_outputs)
    res = run_pipeline(PipelineConfig(seed=args.seed))
    import pandas as pd
    pd.set_option("display.width", 200)
    pd.set_option("display.max_columns", 30)
    print("== Visibility comparison (computed) ==")
    print(metrics_table(res).to_string(index=False))
    full = res["modes"]["FULL_NETWORK_BENCHMARK"]
    print("\n== Ranked cases (FULL_NETWORK_BENCHMARK) ==")
    print(cases_table(full["cases"]).to_string(index=False))
    print("\n== Simulated funds remaining vs response delay (FULL_NETWORK_BENCHMARK) ==")
    print(delay_table(full["simulation"]).to_string(index=False))
    for line in full["simulation"]["assumptions"]:
        print(" *", line)
    print("results written to", write_outputs(res, ROOT / "outputs"))


def cmd_test(_):
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)


def _streamlit_cmd(port):
    return [sys.executable, "-m", "streamlit", "run", str(APP),
            "--server.port", str(port), "--server.address", "127.0.0.1",
            "--server.headless", "true", "--server.enableCORS", "false",
            "--server.enableXsrfProtection", "false", "--browser.gatherUsageStats", "false"]


def cmd_dashboard(args):
    try:
        importlib.import_module("streamlit")
        importlib.import_module("plotly")
    except ImportError as exc:
        sys.exit(f"Dashboard dependency missing: {exc}. See README 'Setup' (the three pip commands).")
    port = find_free_port() if args.port == "auto" else int(args.port)
    if not port_is_free(port):
        sys.exit(f"Port {port} is already in use; choose another or use --port auto")
    if args.background:
        (ROOT / "logs").mkdir(exist_ok=True)
        log = open(ROOT / "logs" / "dashboard.log", "ab")
        proc = subprocess.Popen(_streamlit_cmd(port), stdout=log, stderr=log, cwd=ROOT,
                                start_new_session=True)
        PID_FILE.write_text(json.dumps({"pid": proc.pid, "port": port}))
        print(f"started in background: pid {proc.pid}, port {port}; log: logs/dashboard.log")
        print(f"local URL: http://127.0.0.1:{port}/   (then run: python main.py status)")
    else:
        print(f"local URL: http://127.0.0.1:{port}/   (Ctrl+C to stop)")
        os.execv(sys.executable, _streamlit_cmd(port))


def _read_pid():
    try:
        return json.loads(PID_FILE.read_text())
    except (OSError, ValueError):
        return None


def _is_ours(pid):
    try:
        cmd = Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ").decode()
    except OSError:
        return False
    return "streamlit" in cmd and str(APP) in cmd


def cmd_status(_):
    info = _read_pid()
    if not info or not _is_ours(info["pid"]):
        print("TraceFlow Z dashboard: not running (no matching process from this project)")
        return
    url = f"http://127.0.0.1:{info['port']}/_stcore/health"
    try:
        body = urllib.request.urlopen(url, timeout=5).read().decode().strip()
        print(f"running: pid {info['pid']}, port {info['port']}, health check -> {body}")
    except Exception as exc:
        print(f"process {info['pid']} exists but health check failed: {exc}")


def cmd_stop(_):
    info = _read_pid()
    if not info or not _is_ours(info["pid"]):
        print("Nothing to stop: no dashboard process from this project was found "
              "(other processes, including Jupyter, are never touched).")
        return
    os.kill(info["pid"], 15)
    for _ in range(50):
        if not _is_ours(info["pid"]):
            break
        time.sleep(0.1)
    PID_FILE.unlink(missing_ok=True)
    print(f"stopped dashboard pid {info['pid']}")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check-env").set_defaults(fn=cmd_check_env)
    g = sub.add_parser("generate"); g.add_argument("--seed", type=int, default=42); g.set_defaults(fn=cmd_generate)
    r = sub.add_parser("run"); r.add_argument("--seed", type=int, default=42); r.set_defaults(fn=cmd_run)
    sub.add_parser("test").set_defaults(fn=cmd_test)
    d = sub.add_parser("dashboard"); d.add_argument("--port", default="auto")
    d.add_argument("--background", action="store_true"); d.set_defaults(fn=cmd_dashboard)
    sub.add_parser("status").set_defaults(fn=cmd_status)
    sub.add_parser("stop").set_defaults(fn=cmd_stop)
    args = p.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
