# TraceFlow Z (final, clean build)

Privacy-aware cross-bank fraud investigation and response simulation - **synthetic data only**.
Five modules, one pipeline, one dashboard. Risk scores are investigation aids, not proof of fraud.

| Owner | File | What it does |
|---|---|---|
| Teammate 1 | `src/data_generator.py` | Reproducible 3-bank accounts + transactions, planted suspicious trails, legitimate look-alikes, **separate** ground truth |
| Teammate 2 | `src/graph_tracing.py` | NetworkX graph, bounded temporal multi-hop tracing, explainable 0-100 risk score, cases |
| Teammate 3 | `src/visibility_evaluation.py` | LOCAL_ONLY / SELECTED_SIGNALS / FULL_NETWORK_BENCHMARK views, metrics vs. ground truth |
| Teammate 4 | `src/response_simulator.py` | Explainable case ranking, response-delay / investigator-queue simulation |
| Teammate 5 | `main.py`, `src/dashboard_helpers.py`, `src/dashboard_app.py`, `src/contracts.py` | Contracts, pipeline, CLI, Streamlit dashboard |

Note on ownership: the architecture document puts case **ranking** in Teammate 4's module, so
`rank_cases` lives in `response_simulator.py`; tracing already returns cases sorted by `risk_score`.

## Verified vs. not verified (read this first)
* Built and tested in a sandbox: **x86_64**, Python 3.12.3, pandas 3.0.2, numpy 2.4.4, networkx 3.6.1.
  62 unit/integration tests pass (`python main.py test`).
* **Not verified on s390x / IBM LinuxONE**, not verified with real Streamlit or Plotly (they could not be
  installed there: no network). The dashboard script was executed only against a stub of the Streamlit
  API, so real browser rendering and the Jupyter proxy are untested.
* If a dependency fails on s390x, `python main.py run` still gives the complete experiment in the terminal.

## Setup (copy and paste)
Assumes you uploaded `traceflow_z_final.zip` to `/home/ibm-user/`. Your old `traceflow_z` is not touched.
```bash
cd /home/ibm-user
unzip traceflow_z_final.zip            # creates /home/ibm-user/traceflow_z_final
cd traceflow_z_final
python3 -m venv .venv                  # separate venv; /opt/venv and Jupyter are not touched
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt                 # pandas, numpy, networkx, plotly
python -m pip install -r requirements-dashboard.txt       # streamlit's dependencies, WITHOUT pyarrow
python -m pip install --no-deps "streamlit>=1.35,<1.50"
python main.py check-env               # shows architecture, package status and a free port
```
(`bash scripts/setup_env.sh` does the same steps.) If `pip` cannot build a package on s390x, note the
exact error line; common blockers are `pillow` (needs libjpeg/zlib headers) and `pandas`/`numpy`
(try `python3 -m venv .venv --system-site-packages` to reuse the ones already installed).

## Run the tests
```bash
cd /home/ibm-user/traceflow_z_final && source .venv/bin/activate
python main.py test
```
Works without Streamlit/Plotly (the dashboard test uses a stub when they are missing).

## Run the experiment without a browser
```bash
python main.py run          # prints metrics, ranked cases, delay table; writes outputs/*.csv|json
```

## Start the dashboard
```bash
cd /home/ibm-user/traceflow_z_final && source .venv/bin/activate
python main.py dashboard --port auto --background     # picks a free port from 8511-8599
python main.py status                                  # PID, port and an HTTP health check
```
The printed local URL is `http://127.0.0.1:<port>/`. Port 8502 (old project) and 38888 (Jupyter) are
never used. Confirm it yourself: `curl -s http://127.0.0.1:<port>/_stcore/health` should print `ok`.

## Open it through hosted Jupyter (check the proxy separately)
1. Is the proxy installed? `/opt/venv/bin/python -m pip list 2>/dev/null | grep -i jupyter-server-proxy`
   (read-only check; installing anything there is *not* needed if it already shows).
2. Through the proxy the URL is your Jupyter address with `/proxy/<port>/` appended, e.g.
   `https://<your-jupyter-host>/proxy/8511/` (keep the trailing slash).
3. Test the proxy separately from Streamlit: `curl -s -o /dev/null -w "%{http_code}\n" -H "Authorization: token <JUPYTER_TOKEN>" http://127.0.0.1:38888/proxy/8511/_stcore/health`
   `200` means the proxy path works. If it is `404`, jupyter-server-proxy is missing or disabled: use an
   SSH tunnel instead: `ssh -L 8511:127.0.0.1:8511 <user>@<server>` then open `http://127.0.0.1:8511/`.
The app is started with CORS/XSRF protection off for the proxy case; it listens on 127.0.0.1 only.

## Stop / restart only this app
```bash
python main.py stop      # kills only the PID this project started (verified via /proc cmdline)
python main.py dashboard --port auto --background
```

## Troubleshooting
| Symptom | Fix |
|---|---|
| `Dashboard dependency missing: No module named 'streamlit'` | Run the three install commands above inside the venv (`source .venv/bin/activate`) |
| `ImportError ... pyarrow` when importing streamlit | That Streamlit version needs pyarrow at import time. Try an older Streamlit release with `--no-deps`; if it still fails, check whether a pyarrow wheel exists for s390x, otherwise use `python main.py run` |
| Port already in use | `python main.py dashboard --port auto` |
| Blank page via Jupyter | Wrong URL (needs `/proxy/<port>/`), or proxy missing: use the SSH tunnel |
| `ModuleNotFoundError: src` | Run commands from the project root |
| Check logs | `tail -50 logs/dashboard.log` |

## Documentation
`docs/architecture.md` (interfaces, visibility rules, metric definitions), `docs/data_dictionary.md`,
`docs/demo_script.md`, `docs/interface_checklist.md` (requirement -> test mapping).
